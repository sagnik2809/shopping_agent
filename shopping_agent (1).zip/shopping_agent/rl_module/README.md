# rl_module — Module 4: Reinforcement Learning for memory handling

For every memory the shopping agent retrieves, this module decides **what to do with it**:
`USE`, `VERIFY_USER`, `SEARCH_EVIDENCE`, `IGNORE`, `UPDATE`, or `REMOVE`.
It learns this by practising on thousands of simulated shopping sessions, then is compared
with hand-written rule-based strategies (as the project brief requires).

## 1. Input and output (the contract)

**Input — one `MemoryObs` per retrieved memory** (built from Module 3's `MemoryAssessment`
with `obs_from_module3(...)`):

| field | meaning |
|---|---|
| `memory_id`, `slot` | which memory / which preference (budget, brand, ...) |
| `trust` | Module 3 posterior P(reliable), 0–1 |
| `label` | RELIABLE / OUTDATED / CONFLICTING / UNCERTAIN_INFERRED / SUSPICIOUS |
| `importance` | cost of a wrong value in this slot (budget is high, brand is low) |
| `conflict` | another stored memory contradicts this one |

plus a `SessionContext`: questions the user may still be asked, the user's answer if the
memory was already verified, the evidence hint if a search was done, whether the session is
still clean.

**Output — one `Decision` per memory:** `action` (one of the six), `q_values` (the learned value of
each legal action), `reason` (readable text for Module 5's explanation), `needs_user`
(True when the action is VERIFY_USER).

Interactive use: when the action is `VERIFY_USER` or `SEARCH_EVIDENCE`, the orchestrator performs
it, fills the answer into `SessionContext`, and calls `next_action` again until a *terminal*
action (USE / IGNORE / UPDATE / REMOVE) comes back.

```python
from rl_module import RLMemoryPolicy, obs_from_module3, SessionContext
policy = RLMemoryPolicy.load("rl_module/artifacts/q_policy.json")
obs = [obs_from_module3(a, mem_by_id[a.memory_id]) for a in assessments]   # from Module 3
decisions = policy.decide_batch(obs, questions_left=2)
# ... later, after the user answered "outdated" for one memory:
policy.next_action(obs[0], SessionContext(questions_left=1, verified="outdated"))
```

## 2. Files

| file | job |
|---|---|
| `config.py` | all numbers: actions, labels, **reward table**, simulator assumptions, training settings |
| `state.py` | the input record `MemoryObs` and the discrete `State` the agents learn on |
| `memory_generator.py` | the synthetic world: memories with a hidden truth, a stored value, and three poisoning disguises (blatant / stealth / mimic) |
| `bundles.py` | **verifiable reward**: runs Module 1 on the agent's accepted values and on the true values, and scores the two bundles |
| `environment.py` | the MDP: `reset`, `step`, legal-action mask (the safety shield) |
| `agents.py` | Q-learning, SARSA, LinUCB contextual bandit |
| `baselines.py` | random, always-use, always-verify, rule-based, oracle |
| `train.py` | training loop (+ command line) |
| `evaluate.py` | metrics, identical-session evaluation, confidence intervals |
| `run_experiments.py` | reproduces all 9 experiments, tables and charts |
| `plots.py` | chart helpers |
| `interface.py` | the deployable policy and the adapter from Module 3 |
| `demo_integration.py` | runs the policy on `data/memories.json` through the real Module 3 |
| `tests/test_rl_module.py` | 17 correctness and safety tests |

## 3. The MDP in one page

* **Episode** = one shopping session: 3–6 retrieved memories, a budget of 2 questions to the user.
* **Step** = one action on the current memory. `VERIFY_USER` and `SEARCH_EVIDENCE` gather
  information and stay on the same memory; the other four finish it and move to the next.
* **State** (9 small fields, ~4k reachable combinations): trust bucket, Module 3 label, importance,
  conflict flag, user's answer, evidence hint, questions left, session still clean, more memories follow.
* **Actions** (legal-action mask): no VERIFY without questions left; UPDATE only after VERIFY;
  SEARCH once per memory; **shield:** USE is blocked for SUSPICIOUS memories unless the user confirmed them good.
* **Reward (two parts):**
  1. *Shaping*: outcome of each decision × slot importance (using a poisoned memory −8, removing/updating it +2, using a good one +2),
     minus 0.5 per question and 0.1 per search. Full table in `config.py::RewardConfig`.
  2. *Verifiable session reward* (DeepPlanning-style): when the last memory is handled, Module 1 builds the recommended PC bundle from the
     values the agent let in (USE keeps the stored value, UPDATE restores the true value, IGNORE/REMOVE leave the slot open) and from the
     true preferences. Reward += 3 × Match Score (share of correct products) + 3 × Case Accuracy (whole bundle exactly right).
* **Algorithms:** Q-learning (off-policy), SARSA (on-policy), LinUCB (a bandit that ignores the future).

## 4. How to run

```bash
python -m rl_module.train --algo q_learning        # train, saves artifacts/q_policy.json (~1 min)
python -m rl_module.demo_integration               # decisions on the project's own memories
python rl_module/tests/test_rl_module.py           # 17 tests
python -m rl_module.run_experiments                # all experiments (~8 min on 2 cores)
python -m rl_module.run_experiments --quick        # smoke run, writes to results_quick/, numbers not meaningful
```

## 5. What the results mean, and what they do not

Results are in `artifacts/results/report.md`. Read the following before quoting any number.

* **Everything is relative to the simulator** in `memory_generator.py`. The proportions of stale and
  poisoned memories, how noisy Module 3's labels are, and the reward numbers are *assumptions that I (the
  author of the code) chose*. They show how policies compare under those assumptions, not how real users behave.
* The reward weights are design choices; experiment 6 shows how the behaviour moves when they change.
* "Ground truth" for the bundle reward is *what Module 1 recommends from the true preferences*. It measures damage caused by memory
  mistakes, not the quality of Module 1 itself.
* The three attack families (blatant / stealth / mimic) are *my simulation* of the idea in DrunkAgent that a good attack hides from
  detection; the real DrunkAgent optimises text prompts against an LLM recommender, which this module does not do.
* The state does not include `source` or `age_days` (Module 3 already summarises them in `trust`/`label`).

## 6. How the two reference papers are used

| paper idea | where in the code | experiment |
|---|---|---|
| DeepPlanning: score by comparing the final cart with a ground-truth cart (Match Score, Case Accuracy) | `bundles.py`, reward in `environment.py`, metrics in `evaluate.py` | 1, 8 |
| DeepPlanning: error analysis of why agents fail | failure taxonomy counters (`ev_*`) | 9b |
| DrunkAgent: attacks must be stealthy, work in a black-box setting, and generalise (transfer, universality) | attack families in `memory_generator.py`, `ATTACK_FAMILIES` in `config.py` | 3, 7, 9a |
| DrunkAgent: attack success rate | `attack_success_rate` in `evaluate.py` | 1, 7, 8 |

## 7. Possible extensions

* Wire `src/agent.py` to call this policy instead of the hand-written memory rules.
* Learn from the simulator's trust distribution fitted to real logs, if you ever have any.
* A function-approximation agent (DQN) once the state grows beyond what a table can hold.
