"""
rl_module — Module 4 (Reinforcement Learning) of the Memory-Safe Shopping Agent.

Public entry points:
    ShoppingSessionEnv   the learning environment (simulated shopping sessions)
    make_agent / train   build and train Q-learning, SARSA or LinUCB agents
    RLMemoryPolicy       the deployable policy other modules call
    MemoryObs            the INPUT record describing one retrieved memory
    Decision             the OUTPUT record (one action per memory)
"""
from .config import ACTIONS, LABELS, EnvConfig, RewardConfig
from .state import MemoryObs
from .environment import ShoppingSessionEnv
from .agents import make_agent
from .train import train
from .interface import RLMemoryPolicy, Decision, SessionContext, obs_from_module3

__all__ = [
    "ACTIONS", "LABELS", "EnvConfig", "RewardConfig", "MemoryObs",
    "ShoppingSessionEnv", "make_agent", "train", "RLMemoryPolicy",
    "Decision", "SessionContext", "obs_from_module3",
]
