"""
agents.py — the three learning algorithms the brief suggests.

All share one interface:
    act(state, legal_actions, greedy=False) -> action
    learn(s, a, r, s2, done, a2, legal2)
    q_values(state, legal) -> {action: value}          (for explanations)

QLearningAgent   off-policy TD control:  target = r + gamma * max_a' Q(s', a')
SARSAAgent       on-policy TD control:   target = r + gamma * Q(s', a'), a' = action actually taken
LinUCBAgent      contextual bandit: treats every step as independent (gamma = 0),
                 so it cannot see that a cheap VERIFY now prevents a big loss later.
                 It is included to show WHY sequential RL matters here.
"""
from __future__ import annotations
import json
import random
from collections import defaultdict
from typing import Dict, List, Optional

import numpy as np

from .config import ACTIONS, TrainConfig
from .state import State, state_to_vector, VEC_DIM


class BaseAgent:
    name = "base"

    def __init__(self, seed: int = 0, cfg: Optional[TrainConfig] = None):
        self.cfg = cfg or TrainConfig()
        self.rng = random.Random(seed)
        self.epsilon = 0.0

    def q_values(self, state, legal) -> Dict[str, float]:
        raise NotImplementedError

    def act(self, state: State, legal: List[str], greedy: bool = False) -> str:
        if not greedy and self.rng.random() < self.epsilon:
            return self.rng.choice(legal)
        qs = self.q_values(state, legal)
        best = max(qs.values())
        return self.rng.choice([a for a, v in qs.items() if v >= best - 1e-12])

    def learn(self, s, a, r, s2, done, a2=None, legal2=None) -> None:
        raise NotImplementedError


class _TabularAgent(BaseAgent):
    def __init__(self, seed=0, cfg=None):
        super().__init__(seed, cfg)
        self.q = defaultdict(float)

    def q_values(self, state, legal):
        return {a: self.q[(tuple(state), a)] for a in legal}

    # ---- persistence of the learned Q-table -------------------------------
    def to_dict(self) -> Dict[str, float]:
        return {",".join(map(str, k[0])) + "|" + k[1]: v for k, v in self.q.items() if v != 0.0}

    def load_dict(self, d: Dict[str, float]) -> None:
        self.q = defaultdict(float)
        for key, v in d.items():
            s, a = key.split("|")
            self.q[(tuple(int(x) for x in s.split(",")), a)] = v


class QLearningAgent(_TabularAgent):
    name = "q_learning"

    def learn(self, s, a, r, s2, done, a2=None, legal2=None):
        key = (tuple(s), a)
        target = r
        if not done:
            target += self.cfg.gamma * max(self.q[(tuple(s2), x)] for x in legal2)
        self.q[key] += self.cfg.alpha * (target - self.q[key])


class SARSAAgent(_TabularAgent):
    name = "sarsa"

    def learn(self, s, a, r, s2, done, a2=None, legal2=None):
        key = (tuple(s), a)
        target = r
        if not done:
            target += self.cfg.gamma * self.q[(tuple(s2), a2)]
        self.q[key] += self.cfg.alpha * (target - self.q[key])


class LinUCBAgent(BaseAgent):
    """Per-action ridge regression on the one-hot state vector with an
    upper-confidence exploration bonus. Immediate reward only (bandit)."""
    name = "linucb"

    def __init__(self, seed=0, cfg=None):
        super().__init__(seed, cfg)
        lam = self.cfg.linucb_lambda
        self.A_inv = {a: np.eye(VEC_DIM) / lam for a in ACTIONS}
        self.b = {a: np.zeros(VEC_DIM) for a in ACTIONS}

    def _scores(self, state, legal, explore: bool):
        x = state_to_vector(state)
        out = {}
        for a in legal:
            theta = self.A_inv[a] @ self.b[a]
            bonus = self.cfg.linucb_alpha * float(np.sqrt(x @ self.A_inv[a] @ x)) if explore else 0.0
            out[a] = float(theta @ x) + bonus
        return out

    def q_values(self, state, legal):
        return self._scores(state, legal, explore=False)

    def act(self, state, legal, greedy=False):
        scores = self._scores(state, legal, explore=not greedy)
        best = max(scores.values())
        return self.rng.choice([a for a, v in scores.items() if v >= best - 1e-12])

    def learn(self, s, a, r, s2, done, a2=None, legal2=None):
        x = state_to_vector(s)
        Ai = self.A_inv[a]
        Aix = Ai @ x
        self.A_inv[a] = Ai - np.outer(Aix, Aix) / (1.0 + x @ Aix)   # Sherman-Morrison
        self.b[a] = self.b[a] + r * x


def make_agent(name: str, seed: int = 0, cfg: Optional[TrainConfig] = None) -> BaseAgent:
    table = {"q_learning": QLearningAgent, "sarsa": SARSAAgent, "linucb": LinUCBAgent}
    if name not in table:
        raise ValueError(f"unknown algorithm {name!r}; choose from {list(table)}")
    return table[name](seed=seed, cfg=cfg)
