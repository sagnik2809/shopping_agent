# What the Module 4 results say (read with report.md)

All numbers come from the simulator in `memory_generator.py`; they compare policies under my assumptions, not real users.

1. **Learning did not beat the hand-written rules on return.** Q-learning 7.74 ± 0.15, rule_based 7.83 ± 0.07, always_verify 7.76 ± 0.10: the intervals overlap. Q-learning wins on safety (attack success 0.12 vs 0.22 for rules) but pays by discarding more correct memories (0.14 vs 0.06), so its whole-bundle accuracy (0.60) is below the rules (0.63) and always_verify (0.72, at 2 questions per session).
2. **Attack transfer is the clearest result (Exp 7).** A policy trained only on blatant injections is helpless against stealth attacks (attack success 0.67, worse than rule_based 0.60). Training on stealth fixes stealth (0.09) but not mimic (0.38). Training on the mixed family generalises best (0.10 on its own mix, 0.28 on pure stealth, 0.03 on mimic). This mirrors DrunkAgent's point that defences tuned to one attack style fail on another.
3. **The verifiable bundle reward did not help on its own (Exp 8).** Shaping only gave case accuracy 0.635 ± 0.019; bundle only 0.39 ± 0.10 (it stops asking questions entirely: the final reward is too sparse to teach when to verify); both 0.59 ± 0.02. My expectation that adding the bundle reward improves things was not supported; its value here is as an honest *metric* (match score, case accuracy, attack success).
4. **Poisoned `priority_component` memories are invisible to the bundle reward**, because Module 1 does not use that slot. Only the shaping term penalises them.
5. **Slot targeting (Exp 9a):** no slot is clearly more exploitable for the learned policy; intervals are wide (3 stress seeds).
6. **Seed variance is large for Q-learning** (questions/session 0.71 ± 0.23 on 5 seeds, ±0.6 on 3), so single-seed claims are unreliable.
