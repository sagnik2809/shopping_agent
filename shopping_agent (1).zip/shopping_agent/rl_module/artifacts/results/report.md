# Module 4 results

Training: 150,000 sessions per run. Seeds: 5 (main) / 3 (stress). Evaluation: 4,000 sessions per policy per seed, identical sessions for every policy. All numbers are mean ± 95% CI across seeds and are RELATIVE TO THE SIMULATOR (see memory_generator.py), not real users.

### Experiment 1 — main comparison

| policy | avg_return | match_score | case_accuracy | attack_success_rate | corrupted_use_rate | stale_use_rate | dropped_correct_rate | questions_per_session | searches_per_session |
|---|---|---|---|---|---|---|---|---|---|
| oracle | 12.06 ± 0.03 | 1.000 ± 0.000 | 1.000 ± 0.000 | 0.000 ± 0.000 | 0.000 ± 0.000 | 0.000 ± 0.000 | 0.000 ± 0.000 | 0.00 ± 0.00 | 0.00 ± 0.00 |
| q_learning | 7.74 ± 0.15 | 0.886 ± 0.006 | 0.598 ± 0.015 | 0.123 ± 0.024 | 0.140 ± 0.026 | 0.080 ± 0.011 | 0.138 ± 0.022 | 0.71 ± 0.23 | 1.42 ± 0.23 |
| sarsa | 7.45 ± 0.15 | 0.879 ± 0.008 | 0.580 ± 0.011 | 0.154 ± 0.018 | 0.172 ± 0.019 | 0.112 ± 0.011 | 0.139 ± 0.020 | 0.58 ± 0.19 | 0.65 ± 0.36 |
| rule_based | 7.83 ± 0.07 | 0.884 ± 0.005 | 0.629 ± 0.012 | 0.222 ± 0.007 | 0.265 ± 0.008 | 0.222 ± 0.009 | 0.062 ± 0.002 | 0.58 ± 0.01 | 1.09 ± 0.03 |
| always_verify | 7.76 ± 0.10 | 0.914 ± 0.005 | 0.717 ± 0.011 | 0.134 ± 0.012 | 0.161 ± 0.015 | 0.187 ± 0.007 | 0.040 ± 0.002 | 2.00 ± 0.00 | 0.91 ± 0.03 |
| linucb | 6.92 ± 0.77 | 0.865 ± 0.011 | 0.554 ± 0.047 | 0.243 ± 0.023 | 0.269 ± 0.037 | 0.122 ± 0.030 | 0.130 ± 0.110 | 0.04 ± 0.08 | 0.47 ± 0.10 |
| always_use | 4.23 ± 0.08 | 0.815 ± 0.003 | 0.465 ± 0.010 | 0.329 ± 0.010 | 0.368 ± 0.010 | 1.000 ± 0.000 | 0.020 ± 0.002 | 0.00 ± 0.00 | 0.00 ± 0.00 |
| random | 0.99 ± 0.08 | 0.809 ± 0.003 | 0.371 ± 0.004 | 0.121 ± 0.011 | 0.114 ± 0.011 | 0.315 ± 0.006 | 0.631 ± 0.005 | 1.06 ± 0.02 | 1.12 ± 0.01 |

Reading guide: higher `avg_return`, `match_score`, `case_accuracy` are better (match/case compare the recommended bundle with the one Module 1 builds from the TRUE preferences); lower `attack_success_rate`, `corrupted_use_rate`, `stale_use_rate`, `dropped_correct_rate` are better; `questions_per_session` is the cost to the user. The oracle is an unreachable upper bound.

![learning curves](learning_curves.png)

![main comparison](main_comparison.png)

### Experiment 2 — distribution shift (test corruption rate)

| test rate | policy | avg_return | corrupted_use_rate | questions/session |
|---|---|---|---|---|
| 5% | q_trained_at_5pct | 8.75 ± 0.08 | 0.262 ± 0.090 | 0.45 ± 0.15 |
| 5% | q_trained_at_15pct | 8.24 ± 0.45 | 0.129 ± 0.097 | 0.72 ± 0.70 |
| 5% | rule_based | 8.96 ± 0.14 | 0.260 ± 0.045 | 0.60 ± 0.01 |
| 5% | always_verify | 8.48 ± 0.16 | 0.162 ± 0.042 | 2.00 ± 0.00 |
| 15% | q_trained_at_5pct | 7.38 ± 0.05 | 0.275 ± 0.023 | 0.48 ± 0.12 |
| 15% | q_trained_at_15pct | 7.66 ± 0.53 | 0.130 ± 0.063 | 0.69 ± 0.63 |
| 15% | rule_based | 7.73 ± 0.13 | 0.262 ± 0.016 | 0.58 ± 0.01 |
| 15% | always_verify | 7.69 ± 0.02 | 0.161 ± 0.013 | 2.00 ± 0.00 |
| 30% | q_trained_at_5pct | 5.46 ± 0.48 | 0.274 ± 0.040 | 0.52 ± 0.12 |
| 30% | q_trained_at_15pct | 6.79 ± 0.58 | 0.131 ± 0.062 | 0.64 ± 0.56 |
| 30% | rule_based | 6.03 ± 0.09 | 0.263 ± 0.011 | 0.54 ± 0.01 |
| 30% | always_verify | 6.54 ± 0.29 | 0.162 ± 0.017 | 2.00 ± 0.00 |

### Experiment 3 — stealthy poisoning (fraction of poisoned memories that forge a trusted look)

| stealth rate | policy | avg_return | corrupted_use_rate |
|---|---|---|---|
| 0.0 | q_learning | 8.29 ± 0.59 | 0.014 ± 0.011 |
| 0.0 | rule_based | 9.15 ± 0.14 | 0.020 ± 0.005 |
| 0.0 | always_verify | 8.53 ± 0.18 | 0.025 ± 0.006 |
| 0.3 | q_learning | 7.67 ± 0.36 | 0.135 ± 0.064 |
| 0.3 | rule_based | 7.77 ± 0.23 | 0.271 ± 0.014 |
| 0.3 | always_verify | 7.75 ± 0.37 | 0.166 ± 0.029 |
| 0.6 | q_learning | 7.05 ± 0.54 | 0.248 ± 0.117 |
| 0.6 | rule_based | 6.48 ± 0.21 | 0.507 ± 0.021 |
| 0.6 | always_verify | 6.99 ± 0.28 | 0.294 ± 0.029 |
| 0.9 | q_learning | 6.43 ± 0.86 | 0.371 ± 0.190 |
| 0.9 | rule_based | 5.13 ± 0.33 | 0.754 ± 0.016 |
| 0.9 | always_verify | 6.22 ± 0.31 | 0.434 ± 0.022 |

### Experiment 4 — unreliable user answers (probability VERIFY_USER is wrong)

| user error | policy | avg_return | corrupted_use_rate |
|---|---|---|---|
| 0.0 | q_learning | 7.81 ± 0.35 | 0.127 ± 0.064 |
| 0.0 | rule_based | 7.93 ± 0.14 | 0.268 ± 0.018 |
| 0.0 | always_verify | 7.98 ± 0.19 | 0.150 ± 0.013 |
| 0.1 | q_learning | 7.59 ± 0.26 | 0.132 ± 0.067 |
| 0.1 | rule_based | 7.74 ± 0.17 | 0.268 ± 0.019 |
| 0.1 | always_verify | 7.53 ± 0.14 | 0.172 ± 0.014 |
| 0.3 | q_learning | 7.12 ± 0.39 | 0.146 ± 0.066 |
| 0.3 | rule_based | 7.33 ± 0.18 | 0.267 ± 0.020 |
| 0.3 | always_verify | 6.56 ± 0.17 | 0.221 ± 0.021 |

### Experiment 5 — safety shield ablation (shield masks USE on SUSPICIOUS memories)

| shield | policy | avg_return | corrupted_use_rate |
|---|---|---|---|
| on | q_learning | 7.61 ± 0.38 | 0.127 ± 0.068 |
| on | rule_based | 7.81 ± 0.17 | 0.255 ± 0.023 |
| on | always_use | 4.22 ± 0.24 | 0.357 ± 0.022 |
| off | q_learning | 7.69 ± 0.36 | 0.121 ± 0.103 |
| off | rule_based | 7.81 ± 0.17 | 0.255 ± 0.023 |
| off | always_use | 1.37 ± 0.44 | 1.000 ± 0.000 |

### Experiment 6 — reward sensitivity (penalty for using a poisoned memory; returns are only comparable within one penalty value)

| penalty | policy | avg_return | corrupted_use_rate | questions/session |
|---|---|---|---|---|
| -2 | q_learning | 8.37 ± 0.04 | 0.265 ± 0.025 | 0.46 ± 0.12 |
| -2 | rule_based | 8.57 ± 0.22 | 0.260 ± 0.013 | 0.57 ± 0.04 |
| -8 | q_learning | 7.69 ± 0.36 | 0.131 ± 0.048 | 0.69 ± 0.61 |
| -8 | rule_based | 7.85 ± 0.25 | 0.260 ± 0.013 | 0.57 ± 0.04 |
| -16 | q_learning | 7.10 ± 0.09 | 0.054 ± 0.036 | 1.23 ± 0.43 |
| -16 | rule_based | 6.90 ± 0.30 | 0.260 ± 0.013 | 0.57 ± 0.04 |

### Experiment 7 — attack transfer (policy trained on one poisoning family, tested on each family; blatant = injected third-party text, stealth = forged trusted provenance, mimic = imitates an agent-inferred memory, mixed = 30% stealth + 30% mimic + rest blatant)

| test family | policy | attack_success_rate | case_accuracy | corrupted_use_rate | questions/session |
|---|---|---|---|---|---|
| blatant | train_blatant | 0.002 ± 0.001 | 0.628 ± 0.008 | 0.003 ± 0.002 | 0.31 ± 0.09 |
| blatant | train_stealth | 0.104 ± 0.003 | 0.564 ± 0.054 | 0.108 ± 0.013 | 1.35 ± 0.09 |
| blatant | train_mimic | 0.007 ± 0.004 | 0.616 ± 0.026 | 0.007 ± 0.004 | 0.56 ± 0.13 |
| blatant | train_mixed | 0.002 ± 0.007 | 0.583 ± 0.038 | 0.002 ± 0.008 | 0.81 ± 0.29 |
| blatant | rule_based | 0.019 ± 0.005 | 0.655 ± 0.019 | 0.021 ± 0.006 | 0.57 ± 0.02 |
| blatant | always_verify | 0.024 ± 0.007 | 0.729 ± 0.020 | 0.025 ± 0.006 | 2.00 ± 0.00 |
| blatant | always_use | 0.104 ± 0.006 | 0.490 ± 0.015 | 0.108 ± 0.007 | 0.00 ± 0.00 |
| stealth | train_blatant | 0.672 ± 0.006 | 0.505 ± 0.007 | 0.901 ± 0.028 | 0.22 ± 0.04 |
| stealth | train_stealth | 0.091 ± 0.017 | 0.573 ± 0.047 | 0.104 ± 0.025 | 1.45 ± 0.07 |
| stealth | train_mimic | 0.562 ± 0.014 | 0.504 ± 0.015 | 0.702 ± 0.024 | 0.36 ± 0.09 |
| stealth | train_mixed | 0.282 ± 0.080 | 0.551 ± 0.044 | 0.327 ± 0.105 | 0.91 ± 0.14 |
| stealth | rule_based | 0.595 ± 0.017 | 0.552 ± 0.005 | 0.831 ± 0.017 | 0.58 ± 0.01 |
| stealth | always_verify | 0.372 ± 0.022 | 0.656 ± 0.014 | 0.476 ± 0.013 | 2.00 ± 0.00 |
| stealth | always_use | 0.753 ± 0.016 | 0.403 ± 0.001 | 1.000 ± 0.000 | 0.00 ± 0.00 |
| mimic | train_blatant | 0.527 ± 0.008 | 0.537 ± 0.025 | 0.667 ± 0.033 | 0.28 ± 0.04 |
| mimic | train_stealth | 0.384 ± 0.048 | 0.514 ± 0.042 | 0.473 ± 0.024 | 1.31 ± 0.09 |
| mimic | train_mimic | 0.006 ± 0.003 | 0.599 ± 0.022 | 0.006 ± 0.004 | 0.53 ± 0.11 |
| mimic | train_mixed | 0.030 ± 0.054 | 0.580 ± 0.013 | 0.032 ± 0.061 | 0.89 ± 0.14 |
| mimic | rule_based | 0.168 ± 0.029 | 0.630 ± 0.015 | 0.194 ± 0.026 | 0.57 ± 0.01 |
| mimic | always_verify | 0.109 ± 0.012 | 0.710 ± 0.026 | 0.124 ± 0.007 | 2.00 ± 0.00 |
| mimic | always_use | 0.753 ± 0.011 | 0.403 ± 0.004 | 1.000 ± 0.000 | 0.00 ± 0.00 |
| mixed | train_blatant | 0.401 ± 0.016 | 0.561 ± 0.015 | 0.484 ± 0.006 | 0.28 ± 0.05 |
| mixed | train_stealth | 0.187 ± 0.024 | 0.550 ± 0.032 | 0.215 ± 0.025 | 1.36 ± 0.08 |
| mixed | train_mimic | 0.200 ± 0.005 | 0.573 ± 0.023 | 0.219 ± 0.020 | 0.49 ± 0.11 |
| mixed | train_mixed | 0.102 ± 0.022 | 0.571 ± 0.032 | 0.108 ± 0.033 | 0.87 ± 0.18 |
| mixed | rule_based | 0.268 ± 0.010 | 0.613 ± 0.018 | 0.324 ± 0.012 | 0.58 ± 0.01 |
| mixed | always_verify | 0.165 ± 0.030 | 0.700 ± 0.018 | 0.193 ± 0.020 | 2.00 ± 0.00 |
| mixed | always_use | 0.546 ± 0.016 | 0.435 ± 0.012 | 0.654 ± 0.004 | 0.00 ± 0.00 |

![attack transfer](attack_transfer.png)

### Experiment 8 — reward design (all judged by the same verifiable metrics, not by their own return)

| training reward | case_accuracy | match_score | attack_success_rate | corrupted_use_rate | questions/session |
|---|---|---|---|---|---|
| shaping_only | 0.635 ± 0.019 | 0.896 ± 0.006 | 0.077 ± 0.051 | 0.084 ± 0.065 | 0.99 ± 0.06 |
| bundle_only | 0.390 ± 0.097 | 0.808 ± 0.018 | 0.180 ± 0.085 | 0.172 ± 0.088 | 0.00 ± 0.00 |
| both (ours) | 0.591 ± 0.020 | 0.884 ± 0.005 | 0.121 ± 0.036 | 0.130 ± 0.051 | 0.69 ± 0.62 |

### Experiment 9a — share of poisoned memories USED, by the preference slot the attacker targeted (mixed attacks)

| policy | budget | brand_preference_cpu | brand_preference_gpu | delivery_deadline_days | min_ram_gb | priority_component |
|---|---|---|---|---|---|---|
| q_learning | 0.058 ± 0.033 | 0.166 ± 0.140 | 0.170 ± 0.165 | 0.060 ± 0.055 | 0.052 ± 0.036 | 0.160 ± 0.145 |
| rule_based | 0.329 ± 0.098 | 0.327 ± 0.057 | 0.337 ± 0.082 | 0.331 ± 0.082 | 0.318 ± 0.066 | 0.326 ± 0.060 |
| always_verify | 0.202 ± 0.035 | 0.199 ± 0.058 | 0.195 ± 0.065 | 0.200 ± 0.029 | 0.174 ± 0.035 | 0.194 ± 0.050 |

### Experiment 9b — failure taxonomy, harmful decisions per session (mixed attacks). poison_used / stale_used = used a bad memory with no warning signal at all; good_dropped = threw away a correct memory; wrong_signal = the harmful decision followed a WRONG answer from the user or the evidence search

| policy | poison_used | stale_used | good_dropped | wrong_signal |
|---|---|---|---|---|
| q_learning | 0.051 ± 0.029 | 0.055 ± 0.004 | 0.430 ± 0.136 | 0.180 ± 0.108 |
| rule_based | 0.165 ± 0.018 | 0.118 ± 0.001 | 0.061 ± 0.010 | 0.269 ± 0.001 |
| always_verify | 0.094 ± 0.015 | 0.073 ± 0.013 | 0.033 ± 0.012 | 0.222 ± 0.021 |
