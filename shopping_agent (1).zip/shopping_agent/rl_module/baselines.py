"""
baselines.py — the fixed strategies the learned policies are compared with.

Every policy has the same signature:  policy(state, legal, env) -> action
(`env` is only read by the oracle, which is allowed to peek at the hidden truth.)

random          uniform over legal actions                     (floor)
always_use      trust everything                               (shows the cost of blind trust)
always_verify   ask about every memory while questions last    (shows the cost of nagging)
rule_based      thresholds derived from Module 3's labels      (the fair, hand-written opponent)
oracle          sees the ground truth and may UPDATE for free  (upper bound, not achievable)
"""
from __future__ import annotations
import random
from typing import Callable, List

from .config import LABELS
from .state import State

Policy = Callable[[State, List[str], object], str]


def _legalize(action: str, legal: List[str]) -> str:
    return action if action in legal else "IGNORE"


def make_random(seed: int = 0) -> Policy:
    rng = random.Random(seed)
    return lambda s, legal, env=None: rng.choice(legal)


def always_use(s: State, legal: List[str], env=None) -> str:
    return _legalize("USE", legal)


def _act_on_signal(s: State, legal: List[str]) -> str:
    return _legalize({1: "USE", 2: "UPDATE", 3: "UPDATE"}[s.verified], legal)


def rule_based(s: State, legal: List[str], env=None) -> str:
    label = LABELS[s.label]
    if s.verified:                                   # the user already answered
        return _act_on_signal(s, legal)
    if label == "SUSPICIOUS":
        return _legalize("REMOVE", legal)
    if label in ("CONFLICTING", "OUTDATED"):
        if s.imp and "VERIFY_USER" in legal:
            return "VERIFY_USER"
        if s.searched == 0 and "SEARCH_EVIDENCE" in legal:
            return "SEARCH_EVIDENCE"
        return _legalize("USE" if s.searched == 1 else "IGNORE", legal)
    if label == "UNCERTAIN_INFERRED":
        if s.searched == 0 and "SEARCH_EVIDENCE" in legal:
            return "SEARCH_EVIDENCE"
        return _legalize("USE" if s.searched == 1 else "IGNORE", legal)
    # RELIABLE
    if s.trust_b == 0 and s.imp and "VERIFY_USER" in legal:
        return "VERIFY_USER"
    return _legalize("USE", legal)


def always_verify(s: State, legal: List[str], env=None) -> str:
    if s.verified:
        return _act_on_signal(s, legal)
    if "VERIFY_USER" in legal:
        return "VERIFY_USER"
    return rule_based(s, legal, env)                 # budget exhausted: fall back to the rules


def oracle(s: State, legal: List[str], env) -> str:
    return {"CORRECT": "USE", "STALE": "UPDATE", "CORRUPTED": "UPDATE"}[env.truth]


# the oracle needs privileged stepping (free UPDATE: the true value is restored); evaluate.py checks this set
PRIVILEGED = {"oracle"}

BASELINES = {
    "always_use": always_use,
    "always_verify": always_verify,
    "rule_based": rule_based,
    "oracle": oracle,
}
