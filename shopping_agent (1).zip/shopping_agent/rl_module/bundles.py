"""
bundles.py — turns memory decisions into a REAL recommendation and scores it (DeepPlanning-style).

DeepPlanning scores a shopping agent by comparing the cart it builds with a ground-truth cart:
    Match Score   = (# products in the agent's cart that match the ground truth) / (# ground-truth products)
    Case Accuracy = 1 only if the whole cart matches exactly, else 0
We do the same with Module 1. For one session:
    agent preferences  <- the values the agent let into the recommendation
                          (USE keeps the stored value, UPDATE restores the true value,
                           IGNORE / REMOVE leave the slot unspecified)
    true preferences   <- what the user really wants for the retrieved slots
    ground-truth bundle = Module 1(true preferences);  agent bundle = Module 1(agent preferences)

"Ground truth" here means: what Module 1 recommends when it is given the correct preferences. So the
score measures the damage done by memory mistakes, not the quality of Module 1 itself.

Module 1 (src/csp_search.py) is imported, not modified. Bundles are cached because the number of
distinct preference combinations is small.
"""
from __future__ import annotations
import json
import os
import re
import sys
from functools import lru_cache
from typing import Dict, Optional, Tuple

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)
from src import csp_search  # noqa: E402  (Module 1, unchanged)

_CATALOG: Optional[Dict[str, list]] = None


def _catalog() -> Dict[str, list]:
    global _CATALOG
    if _CATALOG is None:
        with open(os.path.join(ROOT, "data", "products.json")) as f:
            _CATALOG = json.load(f)
    return _CATALOG


def _ram_gb(product: dict) -> int:
    m = re.search(r"(\d+)\s*GB", product["name"])
    return int(m.group(1)) if m else 0


@lru_cache(maxsize=None)
def _bundle_cached(key: Tuple) -> Optional[Tuple[str, ...]]:
    budget, deadline, cpu_brand, gpu_brand, min_ram = key
    catalog = {k: list(v) for k, v in _catalog().items()}
    if min_ram is not None:                      # min_ram_gb is applied as a catalog filter
        catalog["RAM"] = [p for p in catalog["RAM"] if _ram_gb(p) >= min_ram]
    prefs = {
        "budget": budget,
        "delivery_deadline_days": deadline,
        "brand_preferences": {c: b for c, b in (("CPU", cpu_brand), ("GPU", gpu_brand)) if b},
    }
    result = csp_search.solve_with_relaxation(catalog, prefs)
    if not result.get("feasible"):
        return None                              # no recommendation possible
    return tuple(result["assignment"][c]["id"] for c in csp_search.CATEGORY_ORDER)


def bundle_for(prefs: Dict[str, object]) -> Optional[Tuple[str, ...]]:
    """prefs uses the RL slot names; slots that do not affect Module 1 (priority_component) are ignored."""
    key = (prefs.get("budget"), prefs.get("delivery_deadline_days"),
           prefs.get("brand_preference_cpu"), prefs.get("brand_preference_gpu"),
           prefs.get("min_ram_gb"))
    return _bundle_cached(key)


def score_bundle(agent_prefs: Dict[str, object], true_prefs: Dict[str, object]) -> Tuple[float, float]:
    """Returns (match_score, case_accuracy) of the agent's bundle against the ground-truth bundle."""
    truth = bundle_for(true_prefs)
    got = bundle_for(agent_prefs)
    if truth is None:                            # cannot happen with TRUE_VALUES, kept for safety
        return (1.0, 1.0) if got is None else (0.0, 0.0)
    if got is None:
        return 0.0, 0.0
    matches = sum(1 for a, b in zip(got, truth) if a == b)
    match = matches / len(truth)
    return match, 1.0 if matches == len(truth) else 0.0
