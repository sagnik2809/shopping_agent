"""
config.py — every tunable number of the RL module lives here, so reward design
and simulator assumptions are explicit, documented and easy to vary in experiments.
"""
from __future__ import annotations
from dataclasses import dataclass, field, replace
from typing import Dict, Tuple

# ----------------------------------------------------------------------------
# Action space (exactly the six actions named in the project brief)
# ----------------------------------------------------------------------------
ACTIONS = ["USE", "VERIFY_USER", "SEARCH_EVIDENCE", "IGNORE", "UPDATE", "REMOVE"]

# Actions that finish the handling of the current memory. VERIFY_USER and
# SEARCH_EVIDENCE are information-gathering steps: they do not finish it.
TERMINAL_ACTIONS = {"USE", "IGNORE", "UPDATE", "REMOVE"}

# Labels produced by Module 3 (uncertainty.py)
LABELS = ["RELIABLE", "OUTDATED", "CONFLICTING", "UNCERTAIN_INFERRED", "SUSPICIOUS"]

# Hidden ground truth of a stored memory (known to the simulator only)
TRUTHS = ["CORRECT", "STALE", "CORRUPTED"]

# Same importance table as Module 3 (how costly a wrong value in this slot is)
SLOT_IMPORTANCE: Dict[str, float] = {
    "budget": 0.9,
    "brand_preference_cpu": 0.4,
    "brand_preference_gpu": 0.4,
    "delivery_deadline_days": 0.8,
    "min_ram_gb": 0.5,
    "priority_component": 0.3,
}
HIGH_IMPORTANCE_THRESHOLD = 0.5   # importance >= this counts as "high"


@dataclass(frozen=True)
class RewardConfig:
    """
    Reward for handling ONE memory (multiplied by `importance weight`), plus
    costs for gathering information and a session-level bonus.
    All numbers are DESIGN CHOICES — report them as assumptions and run the
    sensitivity experiment (run_experiments.py, experiment 5).
    """
    # --- outcome of the final decision about a memory --------------------
    use_correct: float = 2.0         # used a good memory: useful personalisation
    use_stale: float = -4.0          # used an outdated value
    use_corrupted: float = -8.0      # used a poisoned value (worst outcome)
    ignore_correct: float = -1.0     # threw away something useful
    ignore_stale: float = 0.5
    ignore_corrupted: float = 1.0    # avoided it, but it stays in memory
    remove_correct: float = -3.0     # destroyed a good memory
    remove_stale: float = -0.5
    remove_corrupted: float = 2.0    # cleaned the poisoned memory
    update_stale: float = 2.0        # repaired an outdated value (needs verification)
    update_correct: float = -0.5     # needless rewrite
    update_corrupted: float = 1.5    # overwrote poison with the verified value
    # --- costs of gathering information (NOT scaled by importance) --------
    verify_cost: float = -0.5        # interrupting the user
    search_cost: float = -0.1        # cheap cross-check against other evidence
    # --- verifiable session-level reward ---------------------------------
    bundle_match_weight: float = 3.0   # x Match Score of the final bundle (DeepPlanning-style)
    bundle_case_weight: float = 3.0    # x Case Accuracy (1 only if the WHOLE bundle matches)
    shaping_scale: float = 1.0         # multiplies the per-memory outcome rewards (0 = bundle-only reward)
    low_importance_weight: float = 0.4   # outcome rewards of low-importance slots shrink to 40%

    def with_(self, **kw) -> "RewardConfig":
        return replace(self, **kw)


@dataclass(frozen=True)
class EnvConfig:
    """Assumptions about the simulated world."""
    min_memories: int = 3            # memories retrieved per shopping session
    max_memories: int = 6
    question_budget: int = 2         # how many times the user may be interrupted per session
    corruption_rate: float = 0.15    # P(memory is poisoned)
    stale_rate: float = 0.20         # P(memory is outdated)
    stealth_rate: float = 0.30       # P(poisoned memory is STEALTHY: forged user_stated source, recent, high trust)
    mimic_rate: float = 0.00         # P(poisoned memory MIMICS an agent-inferred memory: mid trust, UNCERTAIN_INFERRED)
                                     # remaining poisoned memories are BLATANT (third-party text, SUSPICIOUS)
    false_alarm_rate: float = 0.02   # P(a correct memory is mislabelled SUSPICIOUS by Module 3)
    search_accuracy: float = 0.80    # SEARCH_EVIDENCE hint is right 80% of the time
    user_error: float = 0.05         # VERIFY_USER answer is wrong 5% of the time
    shield: bool = True              # safety shield masks USE on SUSPICIOUS memories

    def with_(self, **kw) -> "EnvConfig":
        return replace(self, **kw)


@dataclass(frozen=True)
class TrainConfig:
    episodes: int = 150000
    gamma: float = 0.95
    alpha: float = 0.05              # tabular learning rate
    eps_start: float = 1.0
    eps_end: float = 0.05
    eps_decay_frac: float = 0.6      # epsilon reaches eps_end after 60% of training
    linucb_alpha: float = 0.5        # exploration width of LinUCB
    linucb_lambda: float = 1.0       # ridge regulariser of LinUCB


# ----------------------------------------------------------------------------
# Attack families (how a poisoned memory is DISGUISED). Used to train against one
# threat model and test against unseen ones, in the spirit of DrunkAgent's
# black-box transfer evaluation (attack tuned on a surrogate, tested on other victims).
# ----------------------------------------------------------------------------
ATTACK_FAMILIES = {
    "blatant": dict(stealth_rate=0.0, mimic_rate=0.0),   # third-party text, SUSPICIOUS, low trust
    "stealth": dict(stealth_rate=1.0, mimic_rate=0.0),   # forged user_stated source, recent, high trust
    "mimic":   dict(stealth_rate=0.0, mimic_rate=1.0),   # imitates a normal agent-inferred memory
    "mixed":   dict(stealth_rate=0.3, mimic_rate=0.3),   # 40% blatant, 30% stealth, 30% mimic
}

# ----------------------------------------------------------------------------
# Preference values (what a memory actually STATES). The agent never sees these;
# they decide which product bundle Module 1 builds, which is how the reward
# measures the real consequence of every memory decision.
# ----------------------------------------------------------------------------
TRUE_VALUES = {
    "budget": [900, 1000, 1200, 1400, 1800],
    "delivery_deadline_days": [3, 4, 5, 10],
    "brand_preference_cpu": ["AMD", "Intel"],
    "brand_preference_gpu": ["NVIDIA", "AMD"],
    "min_ram_gb": [16, 32],
    "priority_component": ["GPU", "CPU", "Storage"],     # has no effect on the bundle
}
# values an outdated memory may still hold (anything but the current truth)
STALE_VALUES = {
    "budget": [500, 700, 900, 1000, 1200, 1400, 1800, 2500],
    "delivery_deadline_days": [1, 2, 3, 4, 5, 7, 10],
    "brand_preference_cpu": ["AMD", "Intel"],
    "brand_preference_gpu": ["NVIDIA", "AMD"],
    "min_ram_gb": [16, 32],
    "priority_component": ["GPU", "CPU", "Storage"],
}
# values an attacker injects (chosen to change the recommendation)
POISON_VALUES = {
    "budget": [300, 600],                 # impossibly low: forces constraint relaxation
    "delivery_deadline_days": [1, 2],     # impossibly tight
    "brand_preference_cpu": ["AMD", "Intel"],
    "brand_preference_gpu": ["NVIDIA", "AMD"],
    "min_ram_gb": [16, 32],
    "priority_component": ["GPU", "CPU", "Storage"],
}
