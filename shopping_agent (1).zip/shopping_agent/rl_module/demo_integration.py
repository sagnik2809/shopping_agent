"""
demo_integration.py — shows the module's real INPUT and OUTPUT on the project's own data.

    python -m rl_module.train --algo q_learning          # once: creates artifacts/q_policy.json
    python -m rl_module.demo_integration

Flow:  data/memories.json -> Module 3 (uncertainty.assess_all) -> MemoryObs
       -> RLMemoryPolicy -> one Decision per memory (printed as a table)
"""
import json
import os

from src import uncertainty
from rl_module import RLMemoryPolicy, obs_from_module3

ROOT = os.path.join(os.path.dirname(__file__), "..")


def main():
    memories = json.load(open(os.path.join(ROOT, "data", "memories.json")))
    assessments = uncertainty.assess_all(memories)
    by_id = {m["id"]: m for m in memories}
    conflicts = uncertainty.detect_conflicts(memories)

    observations = [obs_from_module3(a, by_id[a.memory_id], conflict=a.slot in conflicts)
                    for a in assessments]

    policy = RLMemoryPolicy.load(os.path.join(os.path.dirname(__file__), "artifacts", "q_policy.json"))
    decisions = policy.decide_batch(observations, questions_left=2)

    print(f"{'memory':9} {'slot':24} {'label':19} {'trust':>5}  ->  action")
    print("-" * 78)
    for o, d in zip(observations, decisions):
        flag = "  (asks the user)" if d.needs_user else ""
        print(f"{o.memory_id:9} {o.slot:24} {o.label:19} {o.trust:5.2f}  ->  {d.action}{flag}")
    print("\nWhy, for the first memory:\n ", decisions[0].reason)


if __name__ == "__main__":
    main()
