"""
environment.py — the learning environment (a Markov decision process).

EPISODE  = one shopping session with 3-6 retrieved memories and a question budget.
STEP     = one action on the CURRENT memory. Memories are handled one after another.
           VERIFY_USER and SEARCH_EVIDENCE gather information and keep the agent on
           the same memory; USE / IGNORE / UPDATE / REMOVE finish it and move on.

Dynamics
  VERIFY_USER      costs verify_cost and one question; reveals the truth
                   (wrong with probability user_error).
  SEARCH_EVIDENCE  costs search_cost; returns a hint "good"/"bad" that is right with
                   probability search_accuracy. Once per memory.
  USE              the memory's stored value enters the recommendation
  UPDATE           the TRUE value enters the recommendation (needs a prior VERIFY_USER:
                   the user supplies the correct value)
  IGNORE / REMOVE  the slot stays unspecified in the recommendation

Reward (two parts)
  1. per-memory outcome rewards (RewardConfig, scaled by slot importance and `shaping_scale`):
     penalties for using outdated / poisoned memories, small costs for questions and searches.
  2. VERIFIABLE session reward (DeepPlanning-style): when the last memory is handled, Module 1 builds
     the recommendation from the values the agent let in; it is compared with the bundle built from the
     true preferences:  bundle_match_weight * MatchScore + bundle_case_weight * CaseAccuracy.

Legal-action mask (the SAFETY SHIELD lives here):
  VERIFY_USER illegal when no questions are left or the memory was already verified
  SEARCH_EVIDENCE illegal after it was used once on this memory
  UPDATE illegal unless the user verified the memory
  USE illegal for SUSPICIOUS memories unless the user verified them as good
      (only when EnvConfig.shield is True)
"""
from __future__ import annotations
import random
from typing import Dict, List, Optional

from .bundles import score_bundle
from .config import (ACTIONS, EnvConfig, RewardConfig, HIGH_IMPORTANCE_THRESHOLD)
from .memory_generator import Memory, generate_session
from .state import MemoryObs, State, encode_state

_TRUTH_TO_SIGNAL = {"CORRECT": 1, "STALE": 2, "CORRUPTED": 3}


class ShoppingSessionEnv:
    def __init__(self, env_cfg: Optional[EnvConfig] = None,
                 reward_cfg: Optional[RewardConfig] = None, seed: int = 0):
        self.cfg = env_cfg or EnvConfig()
        self.rc = reward_cfg or RewardConfig()
        self.base_seed = seed
        self._episode_counter = 0
        self.items: List[Memory] = []

    # ------------------------------------------------------------------ reset
    def reset(self, episode_seed: Optional[int] = None) -> State:
        """Start a new session. Passing the same episode_seed gives the same
        memories, which lets evaluation compare policies on identical sessions."""
        if episode_seed is None:
            episode_seed = self.base_seed * 1_000_003 + self._episode_counter
            self._episode_counter += 1
        gen = random.Random(episode_seed)
        self._noise = random.Random(episode_seed ^ 0x9E3779B9)
        self.items, self.true_prefs = generate_session(gen, self.cfg)
        self.agent_prefs: Dict[str, object] = {}
        self.i = 0
        self.q_left = self.cfg.question_budget
        self.clean = 1
        self.done = False
        self.stats: Dict[str, object] = dict(
            memories=len(self.items), n_correct=0, n_stale=0, n_corrupted=0,
            corrupted_used=0, stale_used=0, dropped_correct=0,
            questions=0, searches=0,
            ev_poison_used=0, ev_stale_used=0, ev_good_dropped=0, ev_wrong_signal=0,
            match_score=0.0, case_accuracy=0.0, attack_success=0, poisoned_session=0,
            poison_slots=[m.obs.slot for m in self.items if m.truth == "CORRUPTED"],
            poison_used_slots=[])
        for m in self.items:
            self.stats["n_" + m.truth.lower()] += 1
        self._begin_memory()
        return self.state()

    def _begin_memory(self) -> None:
        self.verified = 0
        self.searched = 0
        self.signal_wrong = False

    # ------------------------------------------------------------- accessors
    @property
    def mem(self) -> Memory:
        return self.items[self.i]

    @property
    def obs(self) -> MemoryObs:
        return self.mem.obs

    @property
    def truth(self) -> str:
        """Hidden truth. For the oracle baseline and for evaluation ONLY."""
        return self.mem.truth

    def state(self) -> State:
        return encode_state(self.obs, self.verified, self.searched, self.q_left,
                            self.clean, 1 if self.i < len(self.items) - 1 else 0)

    def legal_actions(self) -> List[str]:
        return legal_actions(self.state(), self.obs, self.cfg)

    # ------------------------------------------------------------------ step
    def step(self, action: str, privileged: bool = False):
        """Returns (next_state | None, reward, done, info). `privileged=True`
        skips the legality check (used only by the oracle upper bound)."""
        if self.done:
            raise RuntimeError("episode finished; call reset()")
        if not privileged and action not in self.legal_actions():
            raise ValueError(f"illegal action {action} in state {self.state()}")

        rc, obs, mem = self.rc, self.obs, self.mem
        truth = mem.truth

        # ---- information-gathering actions: stay on the same memory --------
        if action == "VERIFY_USER":
            self.q_left -= 1
            self.stats["questions"] += 1
            signal = _TRUTH_TO_SIGNAL[truth]
            if self._noise.random() < self.cfg.user_error:
                signal = self._noise.choice([s for s in (1, 2, 3) if s != signal])
                self.signal_wrong = True
            self.verified = signal
            return self.state(), rc.verify_cost, False, {}

        if action == "SEARCH_EVIDENCE":
            self.stats["searches"] += 1
            says_good = (truth == "CORRECT")
            if self._noise.random() >= self.cfg.search_accuracy:
                says_good = not says_good
                self.signal_wrong = True
            self.searched = 1 if says_good else 2
            return self.state(), rc.search_cost, False, {}

        # ---- terminal actions: outcome reward, then advance ---------------
        important = obs.importance >= HIGH_IMPORTANCE_THRESHOLD
        w = 1.0 if important else rc.low_importance_weight
        reward = rc.shaping_scale * w * _outcome(rc, action, truth)

        # what the recommendation will be built from
        if action == "USE":
            self.agent_prefs[obs.slot] = mem.stored_value
        elif action == "UPDATE":
            self.agent_prefs[obs.slot] = mem.true_value

        harmful = None
        if action == "USE" and truth == "CORRUPTED":
            self.stats["corrupted_used"] += 1
            self.stats["poison_used_slots"].append(obs.slot)
            self.clean = 0
            harmful = "ev_poison_used"
        elif action == "USE" and truth == "STALE":
            self.stats["stale_used"] += 1
            if important:
                self.clean = 0
            harmful = "ev_stale_used"
        elif action in ("IGNORE", "REMOVE") and truth == "CORRECT":
            self.stats["dropped_correct"] += 1
            if important:
                self.clean = 0
            harmful = "ev_good_dropped"
        if harmful:
            # failure taxonomy: a harmful decision taken on a WRONG signal is its own cause
            self.stats["ev_wrong_signal" if self.signal_wrong else harmful] += 1

        self.i += 1
        if self.i >= len(self.items):
            self.done = True
            match, case = score_bundle(self.agent_prefs, self.true_prefs)
            reward += rc.bundle_match_weight * match + rc.bundle_case_weight * case
            self.stats["match_score"] = match
            self.stats["case_accuracy"] = case
            self.stats["poisoned_session"] = 1 if self.stats["n_corrupted"] > 0 else 0
            self.stats["attack_success"] = 1 if (self.stats["corrupted_used"] > 0 and case == 0.0) else 0
            return None, reward, True, dict(self.stats)

        self._begin_memory()
        return self.state(), reward, False, {}


def _outcome(rc: RewardConfig, action: str, truth: str) -> float:
    return {
        ("USE", "CORRECT"): rc.use_correct, ("USE", "STALE"): rc.use_stale,
        ("USE", "CORRUPTED"): rc.use_corrupted,
        ("IGNORE", "CORRECT"): rc.ignore_correct, ("IGNORE", "STALE"): rc.ignore_stale,
        ("IGNORE", "CORRUPTED"): rc.ignore_corrupted,
        ("REMOVE", "CORRECT"): rc.remove_correct, ("REMOVE", "STALE"): rc.remove_stale,
        ("REMOVE", "CORRUPTED"): rc.remove_corrupted,
        ("UPDATE", "CORRECT"): rc.update_correct, ("UPDATE", "STALE"): rc.update_stale,
        ("UPDATE", "CORRUPTED"): rc.update_corrupted,
    }[(action, truth)]


def legal_actions(state: State, obs: MemoryObs, cfg: EnvConfig) -> List[str]:
    """Shared by the environment and the deployable policy so both obey the same rules."""
    legal = list(ACTIONS)
    if state.q_left <= 0 or state.verified != 0:
        legal.remove("VERIFY_USER")
    if state.searched != 0:
        legal.remove("SEARCH_EVIDENCE")
    if state.verified == 0:
        legal.remove("UPDATE")
    if cfg.shield and obs.label == "SUSPICIOUS" and state.verified != 1:
        legal.remove("USE")
    return legal
