"""
evaluate.py — measure a policy on simulated sessions.

Fairness: every policy is evaluated on the SAME sessions (same episode seeds), so
differences between policies are not caused by lucky memory draws.

Metrics (per policy)
  avg_return             mean total reward per session
  corrupted_use_rate     poisoned memories that were USED / poisoned memories seen
  stale_use_rate         outdated memories that were USED / outdated memories seen
  dropped_correct_rate   good memories IGNORED or REMOVED / good memories seen
  questions_per_session  how often the user was interrupted
  searches_per_session   evidence look-ups per session
  match_score            DeepPlanning-style: share of products in the recommended bundle that equal the
                         bundle built from the TRUE preferences (Module 1 on both sides)
  case_accuracy          share of sessions whose whole bundle is exactly right
  attack_success_rate    DrunkAgent-style: among sessions that contained a poisoned memory, the share where
                         a poisoned value was used AND the final bundle was wrong
Extras (not CI-aggregated): failure taxonomy per session (tax_*) and per-slot poison use (slot_used_*).
"""
from __future__ import annotations
import math
from typing import Callable, Dict, List, Optional

from .config import EnvConfig, RewardConfig, SLOT_IMPORTANCE
from .environment import ShoppingSessionEnv

METRICS = ["avg_return", "match_score", "case_accuracy", "attack_success_rate",
           "corrupted_use_rate", "stale_use_rate", "dropped_correct_rate",
           "questions_per_session", "searches_per_session"]
TAXONOMY = ["ev_poison_used", "ev_stale_used", "ev_good_dropped", "ev_wrong_signal"]
SLOTS = list(SLOT_IMPORTANCE)

_T95 = {1: 12.71, 2: 4.30, 3: 3.18, 4: 2.78, 5: 2.57, 6: 2.45, 7: 2.36, 8: 2.31, 9: 2.26,
        10: 2.23, 15: 2.13, 20: 2.09, 30: 2.04}


def agent_policy(agent) -> Callable:
    return lambda s, legal, env=None: agent.act(s, legal, greedy=True)


def run_policy(policy: Callable, env_cfg: Optional[EnvConfig] = None,
               reward_cfg: Optional[RewardConfig] = None, episodes: int = 2000,
               eval_seed: int = 12345, privileged: bool = False) -> Dict[str, float]:
    env = ShoppingSessionEnv(env_cfg, reward_cfg, seed=0)
    tot = dict(ret=0.0, corr=0, n_corr=0, stale=0, n_stale=0, drop=0, n_good=0,
               q=0, search=0, match=0.0, case=0.0, pois_sess=0, att_succ=0)
    tax = {k: 0 for k in TAXONOMY}
    slot_seen = {k: 0 for k in SLOTS}
    slot_used = {k: 0 for k in SLOTS}
    for ep in range(episodes):
        s = env.reset(episode_seed=eval_seed * 1_000_003 + ep)
        ret = 0.0
        while True:
            a = policy(s, env.legal_actions(), env)
            s2, r, done, info = env.step(a, privileged=privileged)
            ret += r
            if done:
                break
            s = s2
        tot["ret"] += ret
        tot["corr"] += info["corrupted_used"]; tot["n_corr"] += info["n_corrupted"]
        tot["stale"] += info["stale_used"];    tot["n_stale"] += info["n_stale"]
        tot["drop"] += info["dropped_correct"]; tot["n_good"] += info["n_correct"]
        tot["q"] += info["questions"]; tot["search"] += info["searches"]
        tot["match"] += info["match_score"]; tot["case"] += info["case_accuracy"]
        tot["pois_sess"] += info["poisoned_session"]; tot["att_succ"] += info["attack_success"]
        for k in TAXONOMY:
            tax[k] += info[k]
        for sl in info["poison_slots"]:
            slot_seen[sl] += 1
        for sl in info["poison_used_slots"]:
            slot_used[sl] += 1
    nan = float("nan")
    out = {
        "avg_return": tot["ret"] / episodes,
        "match_score": tot["match"] / episodes,
        "case_accuracy": tot["case"] / episodes,
        "attack_success_rate": tot["att_succ"] / tot["pois_sess"] if tot["pois_sess"] else nan,
        "corrupted_use_rate": tot["corr"] / tot["n_corr"] if tot["n_corr"] else nan,
        "stale_use_rate": tot["stale"] / tot["n_stale"] if tot["n_stale"] else nan,
        "dropped_correct_rate": tot["drop"] / tot["n_good"] if tot["n_good"] else nan,
        "questions_per_session": tot["q"] / episodes,
        "searches_per_session": tot["search"] / episodes,
    }
    for k in TAXONOMY:
        out["tax_" + k] = tax[k] / episodes
    for sl in SLOTS:
        out["slot_used_" + sl] = slot_used[sl] / slot_seen[sl] if slot_seen[sl] else nan
    return out


def mean_ci(values: List[float]):
    """Mean and 95% confidence half-width across seeds (Student t)."""
    vals = [v for v in values if not math.isnan(v)]
    n = len(vals)
    if n == 0:
        return float("nan"), float("nan")
    m = sum(vals) / n
    if n == 1:
        return m, 0.0
    sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1))
    df = n - 1
    t = _T95.get(df) or _T95[min((k for k in _T95 if k >= df), default=30)]
    return m, t * sd / math.sqrt(n)


def aggregate(runs: List[Dict[str, float]], keys=None) -> Dict[str, tuple]:
    keys = keys or [k for k in runs[0]]
    return {k: mean_ci([r[k] for r in runs]) for k in keys}
