"""
interface.py — the CONTRACT between the RL module and the rest of the project.

INPUT  (from Module 3 / the orchestrator)
    MemoryObs        one retrieved memory: trust, label, importance, conflict, ...
    SessionContext   what has happened in this session so far: questions left,
                     the user's answer (if the memory was verified), evidence hint
                     (if a search was done), whether the session is still clean.

OUTPUT (to Module 2 planner / Module 1 CSP / Module 5 explainer)
    Decision         action ∈ {USE, VERIFY_USER, SEARCH_EVIDENCE, IGNORE, UPDATE, REMOVE}
                     + the Q-values behind it and a human-readable reason

Interactive use (one memory at a time) is `next_action`. When it returns
VERIFY_USER or SEARCH_EVIDENCE the orchestrator performs that step and calls
`next_action` again with the answer filled into the SessionContext, until a
terminal action (USE / IGNORE / UPDATE / REMOVE) comes back.

`decide_batch` is the non-interactive convenience: it returns the FIRST action for
each memory of a session, spending the question budget in order.
"""
from __future__ import annotations
import json
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from .agents import QLearningAgent
from .baselines import rule_based
from .config import ACTIONS, LABELS, SLOT_IMPORTANCE, EnvConfig
from .environment import legal_actions
from .state import MemoryObs, State, describe_state, encode_state

_VERIFIED = {None: 0, "good": 1, "outdated": 2, "bad": 3}
_SEARCHED = {None: 0, "good": 1, "bad": 2}


@dataclass
class SessionContext:
    questions_left: int = 2
    verified: Optional[str] = None       # user's answer: "good" | "outdated" | "bad"
    evidence: Optional[str] = None       # evidence hint: "good" | "bad"
    session_clean: bool = True
    more_memories: bool = False


@dataclass
class Decision:
    memory_id: str
    action: str
    q_values: Dict[str, float] = field(default_factory=dict)
    reason: str = ""
    needs_user: bool = False             # True when action == VERIFY_USER


class RLMemoryPolicy:
    """Greedy policy over a learned Q-table, with the same legality rules/shield as training."""

    def __init__(self, agent: QLearningAgent, env_cfg: Optional[EnvConfig] = None):
        self.agent = agent
        self.env_cfg = env_cfg or EnvConfig()

    # ----------------------------------------------------------- persistence
    @classmethod
    def load(cls, path: str) -> "RLMemoryPolicy":
        with open(path) as f:
            blob = json.load(f)
        agent = QLearningAgent()
        agent.load_dict(blob["q"])
        return cls(agent, EnvConfig(**blob.get("env", {})))

    def save(self, path: str, algo: str = "q_learning") -> None:
        with open(path, "w") as f:
            json.dump({"algo": algo, "env": self.env_cfg.__dict__, "q": self.agent.to_dict()}, f)

    # --------------------------------------------------------------- decide
    def next_action(self, obs: MemoryObs, ctx: Optional[SessionContext] = None) -> Decision:
        ctx = ctx or SessionContext()
        state = encode_state(obs, _VERIFIED[ctx.verified], _SEARCHED[ctx.evidence],
                             ctx.questions_left, int(ctx.session_clean), int(ctx.more_memories))
        legal = legal_actions(state, obs, self.env_cfg)
        qs = self.agent.q_values(state, legal)

        if all(v == 0.0 for v in qs.values()):          # state never visited in training
            action = rule_based(state, legal)
            reason = "state unseen during training -> fell back to rule-based policy"
        else:
            action = self.agent.act(state, legal, greedy=True)
            top = sorted(qs.items(), key=lambda kv: -kv[1])[:3]
            reason = "best Q-values: " + ", ".join(f"{a}={v:.2f}" for a, v in top)
        return Decision(obs.memory_id, action, qs,
                        f"{reason} | state: {describe_state(state)}",
                        needs_user=(action == "VERIFY_USER"))

    def decide_batch(self, observations: List[MemoryObs], questions_left: int = 2) -> List[Decision]:
        decisions = []
        for i, obs in enumerate(observations):
            ctx = SessionContext(questions_left=questions_left,
                                 more_memories=(i < len(observations) - 1))
            d = self.next_action(obs, ctx)
            if d.action == "VERIFY_USER":
                questions_left -= 1
            decisions.append(d)
        return decisions


def obs_from_module3(assessment, memory: Optional[dict] = None, conflict: bool = False) -> MemoryObs:
    """Adapter: turn a Module 3 `MemoryAssessment` (+ the raw memory dict) into the RL input.
    Uses duck typing, so it needs no import from src/."""
    memory = memory or {}
    slot = assessment.slot
    return MemoryObs(
        memory_id=assessment.memory_id,
        slot=slot,
        trust=float(assessment.confidence),
        label=assessment.label,
        importance=SLOT_IMPORTANCE.get(slot, 0.4),
        conflict=conflict or assessment.label == "CONFLICTING",
        source=memory.get("source", "user_stated"),
        age_days=float(memory.get("age_days", 0.0)),
    )
