"""
memory_generator.py — the synthetic world the agent practises in.

A SESSION has hidden TRUE preferences (budget, deadline, brand, ...). The agent retrieves
3-6 stored memories, one per distinct slot. Each memory has
  * a HIDDEN truth:  CORRECT | STALE | CORRUPTED
  * a STORED VALUE:  the true value (CORRECT), an old value (STALE) or an attacker's value (CORRUPTED)
  * OBSERVABLE features: trust, label, conflict flag...  (what Module 3 would output)

The observable features are NOISY functions of the truth, never perfect. Poisoned memories come in
three disguises (attack families, in the spirit of DrunkAgent's stealth requirement):
  BLATANT  injected from third-party text: low trust, label SUSPICIOUS (what regex/provenance catches)
  STEALTH  forged provenance: claims user_stated, recent, high trust, label RELIABLE
  MIMIC    imitates a normal agent-inferred memory: mid trust, UNCERTAIN_INFERRED — statistically
           identical to genuine inferred memories, so only evidence or the user can tell them apart

This generator is the central ASSUMPTION of the module. State it openly in the report: all results
are relative to this process, not to real users.
"""
from __future__ import annotations
import random
from dataclasses import dataclass
from typing import Dict, List, Tuple

from .config import (EnvConfig, SLOT_IMPORTANCE, TRUE_VALUES, STALE_VALUES, POISON_VALUES)
from .state import MemoryObs


@dataclass(frozen=True)
class Memory:
    obs: MemoryObs          # what the agent can see
    truth: str              # CORRECT | STALE | CORRUPTED   (hidden)
    stored_value: object    # what the memory says
    true_value: object      # what the user really wants for this slot
    attack: str = ""        # "" | "blatant" | "stealth" | "mimic" (hidden, for analysis only)


def _beta(rng: random.Random, a: float, b: float) -> float:
    return rng.betavariate(a, b)


def sample_true_preferences(rng: random.Random) -> Dict[str, object]:
    return {slot: rng.choice(vals) for slot, vals in TRUE_VALUES.items()}


def generate_memory(rng: random.Random, cfg: EnvConfig, idx: int, slot: str, true_value) -> Memory:
    importance = SLOT_IMPORTANCE[slot]

    u = rng.random()
    if u < cfg.corruption_rate:
        truth = "CORRUPTED"
    elif u < cfg.corruption_rate + cfg.stale_rate:
        truth = "STALE"
    else:
        truth = "CORRECT"

    attack = ""
    if truth == "CORRECT":
        stored = true_value
        source = "user_stated" if rng.random() < 0.85 else "agent_inferred"
        age = rng.uniform(0, 180)
        trust = _beta(rng, 7, 2) if source == "user_stated" else _beta(rng, 3, 3)
        conflict = rng.random() < 0.05
        if rng.random() < cfg.false_alarm_rate:
            label, trust = "SUSPICIOUS", min(trust, _beta(rng, 2, 8))
        elif source == "agent_inferred":
            label = "UNCERTAIN_INFERRED"
        elif age > 150 and rng.random() < 0.6:
            label = "OUTDATED"
        elif conflict:
            label = "CONFLICTING"
        else:
            label = "RELIABLE"

    elif truth == "STALE":
        stored = rng.choice([v for v in STALE_VALUES[slot] if v != true_value])
        source = "user_stated" if rng.random() < 0.9 else "agent_inferred"
        age = rng.uniform(100, 400)
        trust = _beta(rng, 3.5, 3)
        conflict = rng.random() < 0.5
        r = rng.random()
        if r < 0.70:
            label = "OUTDATED"
        elif r < 0.85:
            label, conflict = "CONFLICTING", True
        else:
            label = "RELIABLE"           # Module 3 missed it

    else:  # CORRUPTED
        stored = rng.choice([v for v in POISON_VALUES[slot] if v != true_value])
        conflict = rng.random() < 0.10
        r = rng.random()
        if r < cfg.stealth_rate:
            attack = "stealth"
            source = "user_stated"                       # forged provenance
            age = rng.uniform(0, 60)
            trust = _beta(rng, 6, 2)
            label = "RELIABLE" if rng.random() < 0.8 else "UNCERTAIN_INFERRED"
        elif r < cfg.stealth_rate + cfg.mimic_rate:
            attack = "mimic"
            source = "agent_inferred"                    # imitates a genuine inferred memory
            age = rng.uniform(0, 180)
            trust = _beta(rng, 3, 3)                     # same law as genuine inferred memories
            label = "UNCERTAIN_INFERRED"
        else:
            attack = "blatant"
            source = "third_party_injected"
            age = rng.uniform(0, 30)
            trust = _beta(rng, 1, 12)
            label = "SUSPICIOUS" if rng.random() < 0.9 else "UNCERTAIN_INFERRED"

    obs = MemoryObs(memory_id=f"m{idx}", slot=slot, trust=float(trust), label=label,
                    importance=importance, conflict=bool(conflict),
                    source=source, age_days=float(age))
    return Memory(obs, truth, stored, true_value, attack)


def generate_session(rng: random.Random, cfg: EnvConfig) -> Tuple[List[Memory], Dict[str, object]]:
    """Returns (memories, true preferences of the RETRIEVED slots only)."""
    true_prefs = sample_true_preferences(rng)
    n = rng.randint(cfg.min_memories, cfg.max_memories)
    slots = rng.sample(list(SLOT_IMPORTANCE), n)         # one memory per distinct slot
    memories = [generate_memory(rng, cfg, i, slot, true_prefs[slot]) for i, slot in enumerate(slots)]
    return memories, {m.obs.slot: m.true_value for m in memories}
