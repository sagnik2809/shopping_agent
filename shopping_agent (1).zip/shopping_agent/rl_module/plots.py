"""plots.py — chart helpers (kept separate so charts can be re-rendered from the saved CSVs)."""
from __future__ import annotations
import csv
from typing import Dict, List

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

COLORS = {"q_learning": "#2a78d6", "sarsa": "#eb6834", "linucb": "#1baf7a"}
SURFACE, INK, MUTED, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e4e3df"
# vertical nudge (points) so end-of-line labels never overprint each other
LABEL_NUDGE = {"q_learning": 7, "sarsa": -7, "linucb": 0}


def learning_curves_png(curves: Dict[str, List[tuple]], rule_based_return: float, path: str) -> None:
    """curves: {algo: [(sessions, avg_return), ...]}"""
    fig, ax = plt.subplots(figsize=(7.2, 4.0), facecolor=SURFACE)
    ax.set_facecolor(SURFACE)
    xmax = 0
    for algo, pts in curves.items():
        xs, ys = [p[0] for p in pts], [p[1] for p in pts]
        xmax = max(xmax, xs[-1])
        ax.plot(xs, ys, color=COLORS[algo], lw=2, label=algo)
        ax.annotate(algo, (xs[-1], ys[-1]), xytext=(6, LABEL_NUDGE.get(algo, 0)),
                    textcoords="offset points", color=INK, va="center", fontsize=9)
    ax.axhline(rule_based_return, color=MUTED, lw=1, ls="--")
    ax.annotate(f"rule-based policy ({rule_based_return:.2f}, measured separately)",
                (0.01 * xmax, rule_based_return), xytext=(0, 5), textcoords="offset points",
                color=MUTED, fontsize=8)
    ax.set_xlabel("training sessions", color=MUTED)
    ax.set_ylabel("average return during training\n(includes exploration)", color=MUTED)
    ax.set_title("Learning curves (mean over seeds)", color=INK, loc="left", fontsize=11)
    ax.grid(axis="y", color=GRID, lw=0.8)
    for sp in ("top", "right"):
        ax.spines[sp].set_visible(False)
    ax.legend(frameon=False, fontsize=8, loc="lower right")
    ax.set_xlim(0, xmax * 1.18)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def learning_curves_from_csv(csv_path: str, rule_based_return: float, png_path: str) -> None:
    curves: Dict[str, List[tuple]] = {}
    with open(csv_path) as f:
        for row in csv.DictReader(f):
            curves.setdefault(row["algo"], []).append((float(row["sessions"]), float(row["avg_return"])))
    learning_curves_png(curves, rule_based_return, png_path)
