"""
run_experiments.py — reproduces every result of Module 4.

    python -m rl_module.run_experiments            # full run (~15-25 min on 2 cores)
    python -m rl_module.run_experiments --quick    # smoke run (~1 min), numbers NOT meaningful

Experiments (all use identical evaluation sessions for every policy):
  1  main comparison        Q-learning, SARSA, LinUCB vs random / always-use / always-verify /
                            rule-based / oracle, mean ± 95% CI over seeds
  2  distribution shift     train at 5% poisoned memories, test at 5% / 15% / 30%
  3  stealth sweep          what if more poisoned memories forge a trusted-looking source?
  4  user-error sweep       what if the user's answer to VERIFY_USER is sometimes wrong?
  5  shield ablation        safety shield on vs off (train and test in the same setting)
  6  reward sensitivity     vary the penalty for using a poisoned memory
  7  attack transfer        DrunkAgent-style: train on one poisoning family, test on all (black-box transfer)
  8  reward design          DeepPlanning-style verifiable reward: shaping only vs bundle only vs both
  9  where it fails         per-slot poison use and failure taxonomy (learned vs rule-based)
Outputs go to rl_module/artifacts/results/ (CSV tables, PNG charts, report.md).
"""
from __future__ import annotations
import argparse
import csv
import math
import os
import time
from multiprocessing import Pool
from typing import Dict, List

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from .baselines import BASELINES, PRIVILEGED, make_random
from .config import ATTACK_FAMILIES, EnvConfig, RewardConfig, TrainConfig
from .plots import learning_curves_png
from .evaluate import METRICS, SLOTS, TAXONOMY, agent_policy, aggregate, mean_ci, run_policy
from .train import train

OUT = os.path.join(os.path.dirname(__file__), "artifacts", "results")
BASE = EnvConfig()
BLOCK = 1500          # learning curve: mean return per block of this many episodes


# ----------------------------------------------------------------- workers
def _job(args):
    tag, algo, env_cfg, reward_cfg, seed, episodes = args
    agent, rets = train(algo, env_cfg, reward_cfg, TrainConfig(episodes=episodes), seed=seed)
    blocks = [sum(rets[i:i + BLOCK]) / len(rets[i:i + BLOCK]) for i in range(0, len(rets), BLOCK)]
    return tag, algo, seed, agent, blocks


def _eval_policies(agents: Dict[str, object], env_cfg, reward_cfg, episodes, eval_seed,
                   baselines=("random", "always_use", "always_verify", "rule_based", "oracle")):
    res = {}
    for name, agent in agents.items():
        res[name] = run_policy(agent_policy(agent), env_cfg, reward_cfg, episodes, eval_seed)
    for b in baselines:
        if b == "random":
            pol = make_random(eval_seed)
        else:
            pol = BASELINES[b]
        res[b] = run_policy(pol, env_cfg, reward_cfg, episodes, eval_seed, privileged=(b in PRIVILEGED))
    return res


def _write_csv(path, header, rows):
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


def _fmt(m_ci, nd=2):
    m, ci = m_ci
    if math.isnan(m):
        return "n/a"
    return f"{m:.{nd}f} ± {ci:.{nd}f}"


def _table_md(title, header, rows):
    out = [f"### {title}", "", "| " + " | ".join(header) + " |", "|" + "---|" * len(header)]
    out += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(out) + "\n"


# --------------------------------------------------------------- the runner
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--seeds", type=int, default=5)
    ap.add_argument("--stress-seeds", type=int, default=3)
    ap.add_argument("--eval-episodes", type=int, default=4000)
    ap.add_argument("--workers", type=int, default=2)
    a = ap.parse_args()
    episodes = 150000
    if a.quick:
        episodes, a.seeds, a.stress_seeds, a.eval_episodes = 8000, 2, 2, 500
    global OUT
    if a.quick:
        OUT = OUT + "_quick"          # never overwrite the full results with smoke-run numbers
    os.makedirs(OUT, exist_ok=True)
    t0 = time.time()
    report = [f"# Module 4 results\n",
              f"Training: {episodes:,} sessions per run. Seeds: {a.seeds} (main) / {a.stress_seeds} (stress). "
              f"Evaluation: {a.eval_episodes:,} sessions per policy per seed, identical sessions for every policy. "
              f"All numbers are mean ± 95% CI across seeds and are RELATIVE TO THE SIMULATOR "
              f"(see memory_generator.py), not real users.\n"]

    # ---- build every training job up front and run them in parallel -----
    jobs = []
    for seed in range(a.seeds):
        for algo in ("q_learning", "sarsa", "linucb"):
            jobs.append(("main", algo, BASE, RewardConfig(), seed, episodes))
    for seed in range(a.stress_seeds):
        jobs.append(("low_corruption", "q_learning", BASE.with_(corruption_rate=0.05), RewardConfig(), 100 + seed, episodes))
        jobs.append(("no_shield", "q_learning", BASE.with_(shield=False), RewardConfig(), 200 + seed, episodes))
        for pen in (-2.0, -16.0):
            jobs.append((f"pen{pen:g}", "q_learning", BASE, RewardConfig(use_corrupted=pen), 300 + seed, episodes))
    for seed in range(a.stress_seeds):
        for fam, kw in ATTACK_FAMILIES.items():
            jobs.append((f"fam_{fam}", "q_learning", BASE.with_(**kw), RewardConfig(), 400 + seed, episodes))
        jobs.append(("shaping_only", "q_learning", BASE, RewardConfig(bundle_match_weight=0.0, bundle_case_weight=0.0), 500 + seed, episodes))
        jobs.append(("bundle_only", "q_learning", BASE, RewardConfig(shaping_scale=0.0), 600 + seed, episodes))
    print(f"training {len(jobs)} runs on {a.workers} workers ...", flush=True)
    with Pool(a.workers) as pool:
        done = pool.map(_job, jobs, chunksize=1)
    print(f"training done in {time.time() - t0:.0f}s", flush=True)

    trained: Dict[tuple, object] = {}
    curves: Dict[str, List[List[float]]] = {}
    for tag, algo, seed, agent, blocks in done:
        trained[(tag, algo, seed)] = agent
        if tag == "main":
            curves.setdefault(algo, []).append(blocks)

    # ================= Experiment 1: main comparison =====================
    per_seed = {}
    for seed in range(a.seeds):
        agents = {k: trained[("main", k, seed)] for k in ("q_learning", "sarsa", "linucb")}
        r = _eval_policies(agents, BASE, RewardConfig(), a.eval_episodes, 1000 + seed)
        for name, m in r.items():
            per_seed.setdefault(name, []).append(m)
    order = ["oracle", "q_learning", "sarsa", "rule_based", "always_verify", "linucb", "always_use", "random"]
    rows, csv_rows = [], []
    for name in order:
        agg = aggregate(per_seed[name])
        rows.append([name] + [_fmt(agg[m], 3 if ("rate" in m or "acc" in m or "match" in m) else 2) for m in METRICS])
        csv_rows.append([name] + [x for m in METRICS for x in agg[m]])
    _write_csv(f"{OUT}/exp1_main_comparison.csv",
               ["policy"] + [f"{m}_{s}" for m in METRICS for s in ("mean", "ci95")], csv_rows)
    report.append(_table_md("Experiment 1 — main comparison", ["policy"] + METRICS, rows))
    report.append("Reading guide: higher `avg_return`, `match_score`, `case_accuracy` are better (match/case compare "
                  "the recommended bundle with the one Module 1 builds from the TRUE preferences); lower "
                  "`attack_success_rate`, `corrupted_use_rate`, `stale_use_rate`, `dropped_correct_rate` are better; "
                  "`questions_per_session` is the cost to the user. The oracle is an unreachable upper bound.\n")

    # learning curves ------------------------------------------------------
    n_blocks = min(len(c) for algo in curves for c in curves[algo])
    cur_rows, curve_pts = [], {}
    ruleb = mean_ci([m["avg_return"] for m in per_seed["rule_based"]])[0]
    for algo, runs in curves.items():
        mean_curve = [sum(r[b] for r in runs) / len(runs) for b in range(n_blocks)]
        curve_pts[algo] = [((b + 1) * BLOCK, mean_curve[b]) for b in range(n_blocks)]
        cur_rows += [[algo, x, y] for x, y in curve_pts[algo]]
    learning_curves_png(curve_pts, ruleb, f"{OUT}/learning_curves.png")
    _write_csv(f"{OUT}/learning_curves.csv", ["algo", "sessions", "avg_return"], cur_rows)
    report.append("![learning curves](learning_curves.png)\n")

    # bar chart: return and corrupted-use ----------------------------------
    fig, axes = plt.subplots(1, 3, figsize=(12.5, 3.8), facecolor="#fcfcfb")
    bar_order = ["always_use", "linucb", "always_verify", "rule_based", "sarsa", "q_learning"]
    learned = {"q_learning": "#2a78d6", "sarsa": "#eb6834", "linucb": "#1baf7a"}
    for ax, metric, title in ((axes[0], "avg_return", "Average return (higher is better)"),
                              (axes[1], "case_accuracy", "Whole bundle exactly right (higher is better)"),
                              (axes[2], "attack_success_rate", "Attack success rate (lower is better)")):
        vals = [aggregate(per_seed[n])[metric] for n in bar_order]
        ax.set_facecolor("#fcfcfb")
        ax.barh(range(len(bar_order)), [v[0] for v in vals],
                xerr=[v[1] for v in vals], color=[learned.get(n, "#b9b8b2") for n in bar_order],
                height=0.6, error_kw=dict(ecolor="#52514e", lw=1, capsize=2))
        ax.set_yticks(range(len(bar_order)))
        ax.set_yticklabels(bar_order if ax is axes[0] else [], fontsize=9)
        ax.set_title(title, loc="left", fontsize=10, color="#0b0b0b")
        ax.grid(axis="x", color="#e4e3df", lw=0.8)
        ax.set_axisbelow(True)
        for sp in ("top", "right"):
            ax.spines[sp].set_visible(False)
    fig.tight_layout()
    fig.savefig(f"{OUT}/main_comparison.png", dpi=150)
    plt.close(fig)
    report.append("![main comparison](main_comparison.png)\n")

    # ================= Experiment 2: distribution shift ==================
    rows, csv_rows = [], []
    for rate in (0.05, 0.15, 0.30):
        cfg = BASE.with_(corruption_rate=rate)
        runs: Dict[str, list] = {}
        for i in range(a.stress_seeds):
            ag = {"q_trained_at_5pct": trained[("low_corruption", "q_learning", 100 + i)],
                  "q_trained_at_15pct": trained[("main", "q_learning", i)]}
            r = _eval_policies(ag, cfg, RewardConfig(), a.eval_episodes, 2000 + i,
                               baselines=("rule_based", "always_verify"))
            for k, m in r.items():
                runs.setdefault(k, []).append(m)
        for k in ("q_trained_at_5pct", "q_trained_at_15pct", "rule_based", "always_verify"):
            agg = aggregate(runs[k])
            rows.append([f"{int(rate*100)}%", k, _fmt(agg["avg_return"]), _fmt(agg["corrupted_use_rate"], 3),
                         _fmt(agg["questions_per_session"])])
            csv_rows.append([rate, k] + list(agg["avg_return"]) + list(agg["corrupted_use_rate"]) + list(agg["questions_per_session"]))
    _write_csv(f"{OUT}/exp2_distribution_shift.csv",
               ["test_corruption_rate", "policy", "return", "return_ci", "corr_use", "corr_use_ci", "q", "q_ci"], csv_rows)
    report.append(_table_md("Experiment 2 — distribution shift (test corruption rate)",
                            ["test rate", "policy", "avg_return", "corrupted_use_rate", "questions/session"], rows))

    # ================= Experiment 3: stealth sweep ======================
    rows, csv_rows = [], []
    for stealth in (0.0, 0.3, 0.6, 0.9):
        cfg = BASE.with_(stealth_rate=stealth)
        runs = {}
        for i in range(a.stress_seeds):
            r = _eval_policies({"q_learning": trained[("main", "q_learning", i)]}, cfg, RewardConfig(),
                               a.eval_episodes, 3000 + i, baselines=("rule_based", "always_verify"))
            for k, m in r.items():
                runs.setdefault(k, []).append(m)
        for k in ("q_learning", "rule_based", "always_verify"):
            agg = aggregate(runs[k])
            rows.append([f"{stealth:.1f}", k, _fmt(agg["avg_return"]), _fmt(agg["corrupted_use_rate"], 3)])
            csv_rows.append([stealth, k] + list(agg["avg_return"]) + list(agg["corrupted_use_rate"]))
    _write_csv(f"{OUT}/exp3_stealth_sweep.csv", ["stealth_rate", "policy", "return", "return_ci", "corr_use", "corr_use_ci"], csv_rows)
    report.append(_table_md("Experiment 3 — stealthy poisoning (fraction of poisoned memories that forge a trusted look)",
                            ["stealth rate", "policy", "avg_return", "corrupted_use_rate"], rows))

    # ================= Experiment 4: user error ==========================
    rows, csv_rows = [], []
    for ue in (0.0, 0.1, 0.3):
        cfg = BASE.with_(user_error=ue)
        runs = {}
        for i in range(a.stress_seeds):
            r = _eval_policies({"q_learning": trained[("main", "q_learning", i)]}, cfg, RewardConfig(),
                               a.eval_episodes, 4000 + i, baselines=("rule_based", "always_verify"))
            for k, m in r.items():
                runs.setdefault(k, []).append(m)
        for k in ("q_learning", "rule_based", "always_verify"):
            agg = aggregate(runs[k])
            rows.append([f"{ue:.1f}", k, _fmt(agg["avg_return"]), _fmt(agg["corrupted_use_rate"], 3)])
            csv_rows.append([ue, k] + list(agg["avg_return"]) + list(agg["corrupted_use_rate"]))
    _write_csv(f"{OUT}/exp4_user_error.csv", ["user_error", "policy", "return", "return_ci", "corr_use", "corr_use_ci"], csv_rows)
    report.append(_table_md("Experiment 4 — unreliable user answers (probability VERIFY_USER is wrong)",
                            ["user error", "policy", "avg_return", "corrupted_use_rate"], rows))

    # ================= Experiment 5: shield ablation =====================
    rows, csv_rows = [], []
    for shield in (True, False):
        cfg = BASE.with_(shield=shield)
        runs = {}
        for i in range(a.stress_seeds):
            agent = trained[("main", "q_learning", i)] if shield else trained[("no_shield", "q_learning", 200 + i)]
            r = _eval_policies({"q_learning": agent}, cfg, RewardConfig(), a.eval_episodes, 5000 + i,
                               baselines=("always_use", "rule_based"))
            for k, m in r.items():
                runs.setdefault(k, []).append(m)
        for k in ("q_learning", "rule_based", "always_use"):
            agg = aggregate(runs[k])
            rows.append(["on" if shield else "off", k, _fmt(agg["avg_return"]), _fmt(agg["corrupted_use_rate"], 3)])
            csv_rows.append([shield, k] + list(agg["avg_return"]) + list(agg["corrupted_use_rate"]))
    _write_csv(f"{OUT}/exp5_shield_ablation.csv", ["shield", "policy", "return", "return_ci", "corr_use", "corr_use_ci"], csv_rows)
    report.append(_table_md("Experiment 5 — safety shield ablation (shield masks USE on SUSPICIOUS memories)",
                            ["shield", "policy", "avg_return", "corrupted_use_rate"], rows))

    # ================= Experiment 6: reward sensitivity ==================
    rows, csv_rows = [], []
    for pen in (-2.0, -8.0, -16.0):
        rc = RewardConfig(use_corrupted=pen)
        runs = {}
        for i in range(a.stress_seeds):
            agent = trained[("main", "q_learning", i)] if pen == -8.0 else trained[(f"pen{pen:g}", "q_learning", 300 + i)]
            r = _eval_policies({"q_learning": agent}, BASE, rc, a.eval_episodes, 6000 + i, baselines=("rule_based",))
            for k, m in r.items():
                runs.setdefault(k, []).append(m)
        for k in ("q_learning", "rule_based"):
            agg = aggregate(runs[k])
            rows.append([f"{pen:g}", k, _fmt(agg["avg_return"]), _fmt(agg["corrupted_use_rate"], 3),
                         _fmt(agg["questions_per_session"])])
            csv_rows.append([pen, k] + list(agg["avg_return"]) + list(agg["corrupted_use_rate"]) + list(agg["questions_per_session"]))
    _write_csv(f"{OUT}/exp6_reward_sensitivity.csv", ["use_corrupted_penalty", "policy", "return", "return_ci", "corr_use", "corr_use_ci", "q", "q_ci"], csv_rows)
    report.append(_table_md("Experiment 6 — reward sensitivity (penalty for using a poisoned memory; "
                            "returns are only comparable within one penalty value)",
                            ["penalty", "policy", "avg_return", "corrupted_use_rate", "questions/session"], rows))


    # ================= Experiment 7: attack transfer =====================
    fams = list(ATTACK_FAMILIES)
    asr_m, case_m = {}, {}
    rows, csv_rows = [], []
    for test in fams:
        cfg = BASE.with_(**ATTACK_FAMILIES[test])
        runs: Dict[str, list] = {}
        for i in range(a.stress_seeds):
            ag = {f"train_{f}": trained[(f"fam_{f}", "q_learning", 400 + i)] for f in fams}
            r = _eval_policies(ag, cfg, RewardConfig(), a.eval_episodes, 7000 + i,
                               baselines=("rule_based", "always_verify", "always_use"))
            for k, m in r.items():
                runs.setdefault(k, []).append(m)
        for k in [f"train_{f}" for f in fams] + ["rule_based", "always_verify", "always_use"]:
            agg = aggregate(runs[k], ["attack_success_rate", "case_accuracy", "corrupted_use_rate", "questions_per_session"])
            asr_m[(k, test)] = agg["attack_success_rate"][0]
            case_m[(k, test)] = agg["case_accuracy"][0]
            rows.append([test, k, _fmt(agg["attack_success_rate"], 3), _fmt(agg["case_accuracy"], 3),
                         _fmt(agg["corrupted_use_rate"], 3), _fmt(agg["questions_per_session"])])
            csv_rows.append([test, k] + list(agg["attack_success_rate"]) + list(agg["case_accuracy"]) + list(agg["corrupted_use_rate"]) + list(agg["questions_per_session"]))
    _write_csv(f"{OUT}/exp7_attack_transfer.csv", ["test_family", "policy", "asr", "asr_ci", "case_acc", "case_ci", "corr_use", "corr_ci", "q", "q_ci"], csv_rows)
    report.append(_table_md("Experiment 7 — attack transfer (policy trained on one poisoning family, tested on each family; "
                            "blatant = injected third-party text, stealth = forged trusted provenance, mimic = imitates an "
                            "agent-inferred memory, mixed = 30% stealth + 30% mimic + rest blatant)",
                            ["test family", "policy", "attack_success_rate", "case_accuracy", "corrupted_use_rate", "questions/session"], rows))
    pol_rows = [f"train_{f}" for f in fams] + ["rule_based", "always_verify"]
    fig, ax = plt.subplots(figsize=(6.4, 3.8), facecolor="#fcfcfb")
    grid = [[asr_m[(p_, t_)] for t_ in fams] for p_ in pol_rows]
    im = ax.imshow(grid, cmap="Blues", vmin=0, vmax=max(max(r_) for r_ in grid))
    ax.set_xticks(range(len(fams))); ax.set_xticklabels(fams, fontsize=8); ax.set_xlabel("tested on attack family", fontsize=8)
    ax.set_yticks(range(len(pol_rows))); ax.set_yticklabels(pol_rows, fontsize=8)
    for yi, r_ in enumerate(grid):
        for xi, v in enumerate(r_):
            ax.text(xi, yi, f"{v:.2f}", ha="center", va="center", fontsize=8,
                    color="white" if v > 0.5 * max(max(q_) for q_ in grid) else "#0b0b0b")
    ax.set_title("Attack success rate (lower is better)", loc="left", fontsize=10)
    fig.tight_layout(); fig.savefig(f"{OUT}/attack_transfer.png", dpi=150); plt.close(fig)
    report.append("![attack transfer](attack_transfer.png)\n")

    # ================= Experiment 8: reward design =======================
    variants = {"shaping_only": ("shaping_only", 500), "bundle_only": ("bundle_only", 600), "both (ours)": ("main", 0)}
    rows, csv_rows = [], []
    mixed = BASE.with_(**ATTACK_FAMILIES["mixed"])
    for label, (tag, base_seed) in variants.items():
        runs = []
        for i in range(a.stress_seeds):
            ag = trained[(tag, "q_learning", base_seed + i)]
            runs.append(run_policy(agent_policy(ag), BASE, RewardConfig(), a.eval_episodes, 8000 + i))
        agg = aggregate(runs, ["case_accuracy", "match_score", "attack_success_rate", "corrupted_use_rate", "questions_per_session"])
        rows.append([label] + [_fmt(agg[k], 3 if k != "questions_per_session" else 2) for k in
                               ("case_accuracy", "match_score", "attack_success_rate", "corrupted_use_rate", "questions_per_session")])
        csv_rows.append([label] + [x for k in ("case_accuracy", "match_score", "attack_success_rate", "corrupted_use_rate", "questions_per_session") for x in agg[k]])
    _write_csv(f"{OUT}/exp8_reward_design.csv", ["reward", "case_acc", "case_ci", "match", "match_ci", "asr", "asr_ci", "corr", "corr_ci", "q", "q_ci"], csv_rows)
    report.append(_table_md("Experiment 8 — reward design (all judged by the same verifiable metrics, not by their own return)",
                            ["training reward", "case_accuracy", "match_score", "attack_success_rate", "corrupted_use_rate", "questions/session"], rows))

    # ================= Experiment 9: where it fails ======================
    rows, csv_rows = [], []
    runs: Dict[str, list] = {}
    for i in range(a.stress_seeds):
        r = _eval_policies({"q_learning": trained[("fam_mixed", "q_learning", 400 + i)]}, mixed, RewardConfig(),
                           a.eval_episodes, 9000 + i, baselines=("rule_based", "always_verify"))
        for k, m in r.items():
            runs.setdefault(k, []).append(m)
    for k in ("q_learning", "rule_based", "always_verify"):
        agg = aggregate(runs[k])
        rows.append([k] + [_fmt(agg["slot_used_" + sl], 3) for sl in SLOTS])
        csv_rows.append([k] + [x for sl in SLOTS for x in agg["slot_used_" + sl]])
    _write_csv(f"{OUT}/exp9a_poison_use_by_slot.csv", ["policy"] + [f"{sl}_{t}" for sl in SLOTS for t in ("mean", "ci95")], csv_rows)
    report.append(_table_md("Experiment 9a — share of poisoned memories USED, by the preference slot the attacker targeted (mixed attacks)",
                            ["policy"] + SLOTS, rows))
    rows, csv_rows = [], []
    for k in ("q_learning", "rule_based", "always_verify"):
        agg = aggregate(runs[k])
        rows.append([k] + [_fmt(agg["tax_" + t], 3) for t in TAXONOMY])
        csv_rows.append([k] + [x for t in TAXONOMY for x in agg["tax_" + t]])
    _write_csv(f"{OUT}/exp9b_failure_taxonomy.csv", ["policy"] + [f"{t}_{u}" for t in TAXONOMY for u in ("mean", "ci95")], csv_rows)
    report.append(_table_md("Experiment 9b — failure taxonomy, harmful decisions per session (mixed attacks). "
                            "poison_used / stale_used = used a bad memory with no warning signal at all; good_dropped = threw away a correct "
                            "memory; wrong_signal = the harmful decision followed a WRONG answer from the user or the evidence search",
                            ["policy", "poison_used", "stale_used", "good_dropped", "wrong_signal"], rows))

    with open(f"{OUT}/report.md", "w") as f:
        f.write("\n".join(report))
    print(f"all experiments done in {time.time() - t0:.0f}s -> {OUT}/report.md", flush=True)


if __name__ == "__main__":
    main()
