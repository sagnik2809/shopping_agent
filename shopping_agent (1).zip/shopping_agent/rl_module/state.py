"""
state.py — INPUT record (MemoryObs) and the discrete STATE the agents learn on.

Why discretise? The state space has to be small enough for tabular Q-learning /
SARSA to visit every region many times, and the table stays inspectable
("show me what the agent does for an OUTDATED, high-importance budget memory").
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import NamedTuple
import numpy as np

from .config import LABELS, HIGH_IMPORTANCE_THRESHOLD


@dataclass(frozen=True)
class MemoryObs:
    """
    ONE retrieved memory, as described by Module 3. This is the module's INPUT.

    memory_id   id in the memory store
    slot        which preference it is about (budget, brand_preference_cpu, ...)
    trust       Module 3 posterior P(memory is reliable), in [0, 1]
    label       Module 3 label: RELIABLE | OUTDATED | CONFLICTING |
                UNCERTAIN_INFERRED | SUSPICIOUS
    importance  cost of a wrong value in this slot, in [0, 1]
    conflict    True if another stored memory contradicts this one
    source      user_stated | agent_inferred | third_party_injected (informational)
    age_days    age of the memory (informational)
    """
    memory_id: str
    slot: str
    trust: float
    label: str
    importance: float
    conflict: bool = False
    source: str = "user_stated"
    age_days: float = 0.0


class State(NamedTuple):
    trust_b: int     # 0 low (<0.4) | 1 medium (<0.7) | 2 high
    label: int       # index into LABELS
    imp: int         # 0 low | 1 high
    conflict: int    # 0/1
    verified: int    # user's answer: 0 none | 1 "good" | 2 "outdated" | 3 "bad"
    searched: int    # evidence hint:  0 none | 1 "good" | 2 "bad"
    q_left: int      # questions the user may still be asked this session (capped at 2)
    clean: int       # 1 while no harmful outcome happened yet this session
    more: int        # 1 if more memories follow this one


DIMS = (3, len(LABELS), 2, 2, 4, 3, 3, 2, 2)
VEC_DIM = sum(DIMS) + 1          # one-hot of every field + bias

VERIFIED_NAMES = {0: "none", 1: "good", 2: "outdated", 3: "bad"}
SEARCHED_NAMES = {0: "none", 1: "good", 2: "bad"}


def trust_bucket(trust: float) -> int:
    return 0 if trust < 0.4 else (1 if trust < 0.7 else 2)


def encode_state(obs: MemoryObs, verified: int, searched: int,
                 q_left: int, clean: int, more: int) -> State:
    return State(
        trust_b=trust_bucket(obs.trust),
        label=LABELS.index(obs.label),
        imp=1 if obs.importance >= HIGH_IMPORTANCE_THRESHOLD else 0,
        conflict=1 if obs.conflict else 0,
        verified=int(verified),
        searched=int(searched),
        q_left=min(int(q_left), 2),
        clean=int(clean),
        more=int(more),
    )


def state_to_vector(s: State) -> np.ndarray:
    """One-hot encoding used by the LinUCB contextual bandit."""
    v = np.zeros(VEC_DIM)
    offset = 0
    for value, size in zip(s, DIMS):
        v[offset + value] = 1.0
        offset += size
    v[-1] = 1.0
    return v


def describe_state(s: State) -> str:
    return (f"trust={['low','med','high'][s.trust_b]}, label={LABELS[s.label]}, "
            f"importance={'high' if s.imp else 'low'}, conflict={bool(s.conflict)}, "
            f"user_said={VERIFIED_NAMES[s.verified]}, evidence={SEARCHED_NAMES[s.searched]}, "
            f"questions_left={s.q_left}, session_clean={bool(s.clean)}, more_memories={bool(s.more)}")
