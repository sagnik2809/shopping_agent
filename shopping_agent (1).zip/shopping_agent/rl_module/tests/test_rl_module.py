"""
Tests for the RL module.  Run from the project root:
    python -m pytest rl_module/tests -v        (or)        python rl_module/tests/test_rl_module.py
Training in these tests is deliberately short; they check correctness and
safety properties, not final performance.
"""
import os
import sys
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from rl_module import (EnvConfig, RewardConfig, MemoryObs, ShoppingSessionEnv, RLMemoryPolicy,
                       SessionContext, obs_from_module3)
from rl_module.agents import QLearningAgent, make_agent
from rl_module.baselines import BASELINES, make_random, PRIVILEGED
from rl_module.config import ACTIONS, TrainConfig
from rl_module.environment import legal_actions
from rl_module.evaluate import run_policy, agent_policy
from rl_module.state import encode_state
from rl_module.train import train


def _obs(label="RELIABLE", trust=0.8, importance=0.9):
    return MemoryObs("m0", "budget", trust, label, importance)


def test_same_episode_seed_gives_same_session():
    e1, e2 = ShoppingSessionEnv(), ShoppingSessionEnv()
    e1.reset(episode_seed=7); e2.reset(episode_seed=7)
    assert [(m.obs.label, round(m.obs.trust, 6), m.truth, m.stored_value) for m in e1.items] == \
           [(m.obs.label, round(m.obs.trust, 6), m.truth, m.stored_value) for m in e2.items]


def test_legal_action_masks():
    cfg = EnvConfig()
    s = encode_state(_obs(), verified=0, searched=0, q_left=0, clean=1, more=0)
    legal = legal_actions(s, _obs(), cfg)
    assert "VERIFY_USER" not in legal, "no questions left -> cannot verify"
    assert "UPDATE" not in legal, "UPDATE requires a verified memory"
    s2 = encode_state(_obs(), verified=2, searched=1, q_left=1, clean=1, more=0)
    legal2 = legal_actions(s2, _obs(), cfg)
    assert "UPDATE" in legal2 and "VERIFY_USER" not in legal2 and "SEARCH_EVIDENCE" not in legal2


def test_shield_blocks_use_of_suspicious_unless_user_confirmed_good():
    sus = _obs(label="SUSPICIOUS", trust=0.05)
    s = encode_state(sus, 0, 0, 2, 1, 0)
    assert "USE" not in legal_actions(s, sus, EnvConfig(shield=True))
    assert "USE" in legal_actions(s, sus, EnvConfig(shield=False))
    s_ok = encode_state(sus, 1, 0, 1, 1, 0)       # the user confirmed it is good
    assert "USE" in legal_actions(s_ok, sus, EnvConfig(shield=True))


def test_illegal_action_raises():
    env = ShoppingSessionEnv(seed=1); env.reset()
    try:
        env.step("UPDATE")                          # not verified yet
    except ValueError:
        return
    raise AssertionError("illegal UPDATE should raise")


def test_rewards_follow_the_table_and_the_verifiable_bundle_reward():
    rc = RewardConfig()
    env = ShoppingSessionEnv(EnvConfig(min_memories=1, max_memories=1, corruption_rate=1.0,
                                       stale_rate=0.0, stealth_rate=1.0, shield=False), rc, seed=3)
    env.reset()
    assert env.truth == "CORRUPTED"
    _, r, done, info = env.step("USE")
    assert done
    assert info["corrupted_used"] == 1
    w = 1.0 if env.items[0].obs.importance >= 0.5 else rc.low_importance_weight
    expected = rc.shaping_scale * w * rc.use_corrupted + \
        rc.bundle_match_weight * info["match_score"] + rc.bundle_case_weight * info["case_accuracy"]
    assert abs(r - expected) < 1e-9


def test_score_bundle_is_a_verifiable_comparison_with_module1():
    from rl_module.bundles import score_bundle
    from rl_module.memory_generator import sample_true_preferences
    import random
    t = sample_true_preferences(random.Random(1))
    assert score_bundle(t, t) == (1.0, 1.0)
    bad = dict(t, delivery_deadline_days=1)               # nothing can be delivered in 1 day
    assert score_bundle(bad, t) == (0.0, 0.0)


def test_update_restores_truth_and_use_keeps_poison():
    cfg = EnvConfig(min_memories=1, max_memories=1, corruption_rate=1.0, stale_rate=0.0,
                    stealth_rate=1.0, user_error=0.0, shield=False)
    env = ShoppingSessionEnv(cfg, seed=2)
    env.reset(); env.step("VERIFY_USER")
    _, _, _, info = env.step("UPDATE")
    assert info["case_accuracy"] == 1.0 and info["attack_success"] == 0
    env.reset()
    _, _, _, info = env.step("USE")
    assert info["corrupted_used"] == 1 and info["match_score"] <= 1.0


def test_attack_families_have_the_documented_disguises():
    from rl_module.config import ATTACK_FAMILIES
    for fam, source, label in (("blatant", "third_party_injected", "SUSPICIOUS"),
                               ("stealth", "user_stated", "RELIABLE"),
                               ("mimic", "agent_inferred", "UNCERTAIN_INFERRED")):
        env = ShoppingSessionEnv(EnvConfig(corruption_rate=1.0, stale_rate=0.0, **ATTACK_FAMILIES[fam]), seed=1)
        for ep in range(30):
            env.reset(episode_seed=ep)
            for m in env.items:
                assert m.attack == fam and m.obs.source == source


def test_failure_taxonomy_marks_wrong_signal_cases():
    cfg = EnvConfig(min_memories=1, max_memories=1, corruption_rate=1.0, stale_rate=0.0,
                    stealth_rate=1.0, user_error=1.0, shield=False)    # the user always answers wrongly
    env = ShoppingSessionEnv(cfg, seed=4)
    env.reset(); env.step("VERIFY_USER")
    if env.verified == 1:                                   # wrongly told "good" -> USE is the trap
        _, _, _, info = env.step("USE")
        assert info["ev_wrong_signal"] == 1 and info["ev_poison_used"] == 0


def test_verify_costs_a_question_and_budget_is_enforced():
    env = ShoppingSessionEnv(EnvConfig(question_budget=1, min_memories=2, max_memories=2), seed=5)
    env.reset()
    _, r, done, _ = env.step("VERIFY_USER")
    assert r == RewardConfig().verify_cost and not done
    env.step("IGNORE")                              # next memory
    assert "VERIFY_USER" not in env.legal_actions()


def test_episode_always_terminates_with_all_policies():
    for name, pol in list(BASELINES.items()) + [("random", make_random(0))]:
        m = run_policy(pol, episodes=200, privileged=(name in PRIVILEGED))
        assert m["avg_return"] == m["avg_return"], name


def test_oracle_is_upper_bound_and_random_is_floor():
    res = {n: run_policy(p, episodes=1500, privileged=(n in PRIVILEGED))["avg_return"]
           for n, p in list(BASELINES.items()) + [("random", make_random(0))]}
    assert res["oracle"] >= max(v for k, v in res.items() if k != "oracle")
    assert res["random"] <= min(v for k, v in res.items() if k != "random")


def test_learning_beats_random_and_blind_trust():
    for algo in ("q_learning", "sarsa", "linucb"):
        agent, _ = train(algo, train_cfg=TrainConfig(episodes=15000, alpha=0.1), seed=0)
        learned = run_policy(agent_policy(agent), episodes=1500)["avg_return"]
        rand = run_policy(make_random(0), episodes=1500)["avg_return"]
        blind = run_policy(BASELINES["always_use"], episodes=1500)["avg_return"]
        assert learned > rand and learned > blind, (algo, learned, rand, blind)


def test_trained_policy_never_uses_suspicious_memory_with_shield():
    agent, _ = train("q_learning", train_cfg=TrainConfig(episodes=5000), seed=0)
    env = ShoppingSessionEnv(seed=9)
    for ep in range(300):
        s = env.reset(episode_seed=ep)
        while True:
            a = agent.act(s, env.legal_actions(), greedy=True)
            if env.obs.label == "SUSPICIOUS" and s.verified != 1:
                assert a != "USE"
            s, _, done, _ = env.step(a)
            if done:
                break


def test_interface_roundtrip_and_valid_output():
    agent, _ = train("q_learning", train_cfg=TrainConfig(episodes=5000), seed=0)
    pol = RLMemoryPolicy(agent)
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "p.json")
        pol.save(path)
        pol2 = RLMemoryPolicy.load(path)
    obs = [_obs("RELIABLE"), _obs("SUSPICIOUS", 0.05), _obs("OUTDATED", 0.5), _obs("CONFLICTING", 0.4)]
    d1 = pol.decide_batch(obs, questions_left=2)
    d2 = pol2.decide_batch(obs, questions_left=2)
    assert [x.action for x in d1] == [x.action for x in d2]
    assert all(x.action in ACTIONS for x in d1)
    assert all(x.action != "USE" for x, o in zip(d1, obs) if o.label == "SUSPICIOUS")
    assert sum(x.needs_user for x in d1) <= 2, "must respect the question budget"


def test_interface_interactive_flow():
    agent, _ = train("q_learning", train_cfg=TrainConfig(episodes=5000), seed=0)
    pol = RLMemoryPolicy(agent)
    d = pol.next_action(_obs("OUTDATED", 0.5), SessionContext(questions_left=2, verified="outdated"))
    assert d.action in ("UPDATE", "REMOVE", "IGNORE", "USE")


def test_module3_adapter():
    class A:  # duck-typed MemoryAssessment
        memory_id, slot, confidence, label = "mem_002", "budget", 0.57, "OUTDATED"
    o = obs_from_module3(A(), {"source": "user_stated", "age_days": 210})
    assert o.importance == 0.9 and o.label == "OUTDATED" and o.age_days == 210


if __name__ == "__main__":
    tests = [(k, v) for k, v in list(globals().items()) if k.startswith("test_")]
    failed = 0
    for name, fn in tests:
        try:
            fn(); print("PASS", name)
        except Exception as e:
            failed += 1; print("FAIL", name, "->", repr(e))
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)
