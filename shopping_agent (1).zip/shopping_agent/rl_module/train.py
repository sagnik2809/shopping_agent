"""
train.py — the training loop.

For each episode (= one simulated shopping session):
    s = env.reset();   a = agent.act(s)            # epsilon-greedy over LEGAL actions
    repeat:  s2, r, done = env.step(a)
             a2 = agent.act(s2)                    # chosen BEFORE the update (needed by SARSA)
             agent.learn(s, a, r, s2, done, a2)    # temporal-difference update
Epsilon decays linearly from eps_start to eps_end over the first
eps_decay_frac of training: explore early, exploit later.

Command line:
    python -m rl_module.train --algo q_learning --episodes 150000 --out rl_module/artifacts/q_policy.json
"""
from __future__ import annotations
import argparse
import json
import os
from typing import List, Optional, Tuple

from .agents import BaseAgent, make_agent
from .config import EnvConfig, RewardConfig, TrainConfig
from .environment import ShoppingSessionEnv


def train(algo: str = "q_learning", env_cfg: Optional[EnvConfig] = None,
          reward_cfg: Optional[RewardConfig] = None, train_cfg: Optional[TrainConfig] = None,
          seed: int = 0, verbose: bool = False) -> Tuple[BaseAgent, List[float]]:
    """Returns (trained agent, list of the return of every training episode)."""
    tc = train_cfg or TrainConfig()
    env = ShoppingSessionEnv(env_cfg, reward_cfg, seed=seed)
    agent = make_agent(algo, seed=seed, cfg=tc)
    returns: List[float] = []
    decay_steps = max(1, int(tc.episodes * tc.eps_decay_frac))

    for ep in range(tc.episodes):
        agent.epsilon = max(tc.eps_end, tc.eps_start - (tc.eps_start - tc.eps_end) * ep / decay_steps)
        s = env.reset()
        legal = env.legal_actions()
        a = agent.act(s, legal)
        total = 0.0
        while True:
            s2, r, done, _ = env.step(a)
            total += r
            if done:
                agent.learn(s, a, r, None, True)
                break
            legal2 = env.legal_actions()
            a2 = agent.act(s2, legal2)
            agent.learn(s, a, r, s2, False, a2, legal2)
            s, a = s2, a2
        returns.append(total)
        if verbose and (ep + 1) % 5000 == 0:
            recent = sum(returns[-5000:]) / 5000
            print(f"  [{algo}] episode {ep + 1:>6}  eps={agent.epsilon:.2f}  avg return (last 5k)={recent:6.2f}")
    return agent, returns


def main() -> None:
    p = argparse.ArgumentParser(description="Train an RL memory-handling policy")
    p.add_argument("--algo", default="q_learning", choices=["q_learning", "sarsa", "linucb"])
    p.add_argument("--episodes", type=int, default=150000)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--corruption-rate", type=float, default=0.15)
    p.add_argument("--out", default=os.path.join(os.path.dirname(__file__), "artifacts", "q_policy.json"))
    args = p.parse_args()

    env_cfg = EnvConfig(corruption_rate=args.corruption_rate)
    agent, returns = train(args.algo, env_cfg, train_cfg=TrainConfig(episodes=args.episodes),
                           seed=args.seed, verbose=True)
    if hasattr(agent, "to_dict"):
        os.makedirs(os.path.dirname(args.out), exist_ok=True)
        with open(args.out, "w") as f:
            json.dump({"algo": args.algo, "env": env_cfg.__dict__, "q": agent.to_dict()}, f)
        print(f"saved Q-table with {len(agent.to_dict())} entries -> {args.out}")
    else:
        print("LinUCB has no tabular policy file to save (it keeps matrices in memory).")


if __name__ == "__main__":
    main()
