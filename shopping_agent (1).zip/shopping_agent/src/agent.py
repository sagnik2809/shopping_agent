"""
Orchestrator: Memory-Safe Personal Shopping Agent

Wires Modules 1-5 together end to end:
  1. (Module 5) extract any new preferences from trusted chat input
  2. (Module 3) assess reliability of every stored memory relevant to this request
  3. (Module 4) for each memory, decide an action (use/verify/search/ignore/update/remove)
     using the trained RL policy (falls back to rule-based if requested)
  4. (Module 2) build a plan of information-gathering + recommendation actions,
     inserting ValidateMemory/AskClarification only for memories the RL/rule policy
     flagged as needing attention
  5. (Module 1) solve the CSP (with soft-constraint relaxation) / run search to find
     the recommended product bundle using only the memories that were accepted
  6. (Module 5) generate the final explanation
"""

from __future__ import annotations
import json
import os
from typing import Dict, List, Optional

from . import csp_search, planning, uncertainty, rl_agent, llm_interface


DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")


def load_catalog() -> Dict[str, list]:
    with open(os.path.join(DATA_DIR, "products.json")) as f:
        return json.load(f)


def load_memories() -> List[dict]:
    with open(os.path.join(DATA_DIR, "memories.json")) as f:
        return json.load(f)


class ShoppingAgent:
    def __init__(self, catalog: Optional[Dict[str, list]] = None,
                 memories: Optional[List[dict]] = None,
                 use_rl_policy: bool = True):
        self.catalog = catalog if catalog is not None else load_catalog()
        self.memories = memories if memories is not None else load_memories()
        self.use_rl_policy = use_rl_policy
        self._trained_agent = rl_agent.train() if use_rl_policy else None

    # -- Module 5: trusted chat ingestion --------------------------------------
    def ingest_chat_message(self, raw_text: str) -> Dict[str, object]:
        tagged = llm_interface.tag_source(raw_text, "user_chat")
        return llm_interface.extract_preferences_from_chat(tagged)

    def ingest_untrusted_text(self, raw_text: str, source: str) -> str:
        """
        Demonstrates the injection defense: untrusted text is sanitized and
        returned as plain data. It is NEVER written into self.memories or
        used as a preference — that boundary is architectural, not just a filter.
        """
        tagged = llm_interface.tag_source(raw_text, source)
        return tagged["text"]

    # -- Modules 3 + 4: memory assessment and per-memory action ----------------
    def decide_memory_actions(self):
        assessments = uncertainty.assess_all(self.memories)
        decisions = {}
        for a in assessments:
            state = (rl_agent.confidence_bucket(a.confidence), a.label,
                      rl_agent.importance_bucket(uncertainty.SLOT_IMPORTANCE.get(a.slot, 0.4)))
            if self.use_rl_policy:
                action = self._trained_agent.choose_action(state, greedy=True)
            else:
                action = rl_agent.rule_based_policy(state)
            decisions[a.memory_id] = action
        return assessments, decisions

    # -- Module 2: plan -----------------------------------------------------
    def make_plan(self, assessments, decisions):
        memories_to_verify = [a.memory_id for a in assessments
                               if decisions[a.memory_id] in ("VERIFY_USER",)]
        # SUSPICIOUS memories chosen for REMOVE don't need a plan step; they're just dropped.
        slots_needing_clarification = [a.slot for a in assessments
                                        if decisions[a.memory_id] == "VERIFY_USER"
                                        and a.label == "CONFLICTING"]
        plan = planning.build_plan(memories_to_verify, slots_needing_clarification)
        return plan

    # -- assemble trusted preference dict from surviving memories -----------
    def resolve_preferences(self, assessments, decisions, explicit_preferences: Dict[str, object]):
        kept_memories = [m for m in self.memories
                          if decisions[m["id"]] in ("USE", "VERIFY_USER", "SEARCH_EVIDENCE")]
        # memories the policy said to REMOVE/IGNORE are excluded outright (this is where
        # the malicious third-party-injected memory gets dropped before it can influence
        # the recommendation)
        usable = uncertainty.usable_preferences(kept_memories, assessments)

        preferences: Dict[str, object] = {}
        if "budget" in usable:
            preferences["budget"] = usable["budget"]["value"]
        if "delivery_deadline_days" in usable:
            preferences["delivery_deadline_days"] = usable["delivery_deadline_days"]["value"]

        brand_preferences = {}
        if "brand_preference_cpu" in usable:
            brand_preferences["CPU"] = usable["brand_preference_cpu"]["value"]
        if "brand_preference_gpu" in usable:
            brand_preferences["GPU"] = usable["brand_preference_gpu"]["value"]
        preferences["brand_preferences"] = brand_preferences

        # explicit chat-stated preferences (this turn) override stored memory
        preferences.update({k: v for k, v in explicit_preferences.items() if k != "brand_preferences"})
        if "brand_preference_cpu" in explicit_preferences:
            preferences["brand_preferences"]["CPU"] = explicit_preferences["brand_preference_cpu"]
        if "brand_preference_gpu" in explicit_preferences:
            preferences["brand_preferences"]["GPU"] = explicit_preferences["brand_preference_gpu"]

        return preferences

    # -- Module 1 + full pipeline --------------------------------------------
    def recommend(self, chat_message: str = "") -> Dict[str, object]:
        explicit_prefs = self.ingest_chat_message(chat_message) if chat_message else {}

        assessments, decisions = self.decide_memory_actions()
        plan = self.make_plan(assessments, decisions)
        preferences = self.resolve_preferences(assessments, decisions, explicit_prefs)

        result = csp_search.solve_with_relaxation(self.catalog, preferences)

        explanation = llm_interface.build_explanation(
            result, assessments, result.get("relaxed_constraints", []), preferences)

        return {
            "preferences_used": preferences,
            "memory_assessments": [a.__dict__ for a in assessments],
            "memory_actions": decisions,
            "plan": [a.name for a in plan],
            "plan_explained": planning.explain_plan(plan),
            "csp_result": result,
            "explanation": explanation,
        }
