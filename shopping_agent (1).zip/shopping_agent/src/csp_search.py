"""
Module 1: Search and Constraint Satisfaction

The multi-product PC-build selection task is formulated as a CSP:

  Variables:   one per component category, e.g. CPU, Motherboard, RAM, GPU, Storage, PSU, Case
  Domains:     the list of candidate products (dicts) available in that category
  Constraints:
    HARD:
      - socket compatibility:      CPU.socket == Motherboard.socket
      - ram compatibility:         RAM.ram_type == Motherboard.ram_type
      - psu sufficiency:           PSU.wattage >= required_wattage(CPU, GPU)
      - stock / delivery deadline: product.in_stock and product.delivery_days <= deadline
    SOFT (may be relaxed, in priority order — lowest priority relaxed first):
      - budget:            sum(prices) <= budget
      - brand preference:  product.brand == preferred_brand (per category)

The same state space is also searched with uninformed/informed search algorithms
(Uniform-Cost Search, Greedy Best-First Search, A*) where a "state" is a partial
assignment (which categories are already chosen), actions assign a value to the next
unassigned variable, path cost = accumulated price, and the A* heuristic is the sum of
the cheapest remaining option per unassigned category (admissible: never overestimates
the true minimum remaining cost).
"""

from __future__ import annotations
import heapq
import itertools
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple


CATEGORY_ORDER = ["CPU", "Motherboard", "RAM", "GPU", "Storage", "PSU", "Case"]


# ---------------------------------------------------------------------------
# Constraint definitions
# ---------------------------------------------------------------------------

@dataclass
class Constraint:
    name: str
    kind: str            # "hard" or "soft"
    priority: int         # lower = relaxed first when kind == "soft"
    check: Callable[[Dict[str, Any]], bool]   # takes full assignment dict -> bool
    description: str = ""


def required_wattage(assignment: Dict[str, Any]) -> int:
    base = 150  # motherboard/fans/storage baseline
    cpu = assignment.get("CPU")
    gpu = assignment.get("GPU")
    if cpu:
        base += cpu.get("power_draw", 65)
    if gpu:
        base += gpu.get("power_draw", 0)
    return int(base * 1.2)  # 20% headroom


def build_constraints(preferences: Dict[str, Any]) -> List[Constraint]:
    budget = preferences.get("budget")
    deadline = preferences.get("delivery_deadline_days")
    brand_prefs = preferences.get("brand_preferences", {})  # {category: brand}

    constraints: List[Constraint] = []

    def socket_ok(a):
        if "CPU" in a and "Motherboard" in a:
            return a["CPU"]["socket"] == a["Motherboard"]["socket"]
        return True

    def ram_ok(a):
        if "RAM" in a and "Motherboard" in a:
            return a["RAM"]["ram_type"] == a["Motherboard"]["ram_type"]
        return True

    def psu_ok(a):
        if "PSU" in a and ("CPU" in a or "GPU" in a):
            return a["PSU"]["wattage"] >= required_wattage(a)
        return True

    def stock_ok(a):
        for v in a.values():
            if not v.get("in_stock", True):
                return False
            if deadline is not None and v.get("delivery_days", 0) > deadline:
                return False
        return True

    constraints.append(Constraint("socket_compat", "hard", 0, socket_ok,
                                   "CPU socket must match motherboard socket"))
    constraints.append(Constraint("ram_compat", "hard", 0, ram_ok,
                                   "RAM type must match motherboard supported type"))
    constraints.append(Constraint("psu_sufficient", "hard", 0, psu_ok,
                                   "PSU wattage must exceed CPU+GPU draw with headroom"))
    constraints.append(Constraint("stock_deadline", "hard", 0, stock_ok,
                                   "All parts must be in stock and deliverable by deadline"))

    if budget is not None:
        def budget_ok(a, _b=budget):
            return sum(v["price"] for v in a.values()) <= _b
        constraints.append(Constraint("budget", "soft", 1, budget_ok,
                                       f"Total price must not exceed ${budget}"))

    for cat, brand in brand_prefs.items():
        def brand_ok(a, _c=cat, _br=brand):
            return _c not in a or a[_c]["brand"] == _br
        constraints.append(Constraint(f"brand_{cat}", "soft", 2, brand_ok,
                                       f"{cat} should be brand {brand}"))

    return constraints


def check_all(assignment: Dict[str, Any], constraints: List[Constraint]) -> Tuple[bool, List[str]]:
    """Returns (all HARD constraints in the given list satisfied, list of ALL violated constraint names)."""
    violated = [c.name for c in constraints if not c.check(assignment)]
    hard_violated = [c.name for c in constraints if c.kind == "hard" and not c.check(assignment)]
    return len(hard_violated) == 0, violated


def check_required(assignment: Dict[str, Any], constraints: List[Constraint]) -> bool:
    """Returns True only if EVERY constraint passed in is satisfied, regardless of kind.
    Used during search where the caller has already decided which soft constraints
    are 'active' (still required) vs already relaxed."""
    return all(c.check(assignment) for c in constraints)


# ---------------------------------------------------------------------------
# Backtracking CSP solver with forward checking + soft-constraint relaxation
# ---------------------------------------------------------------------------

def backtracking_solve(catalog: Dict[str, List[dict]], constraints: List[Constraint],
                        order: List[str] = None) -> Optional[Dict[str, Any]]:
    order = order or CATEGORY_ORDER
    order = [c for c in order if c in catalog]

    hard_constraints = [c for c in constraints if c.kind == "hard"]

    def backtrack(assignment, remaining):
        if not remaining:
            # every constraint passed to this solve call (hard + whichever soft
            # constraints the caller still considers "active") must hold
            return dict(assignment) if check_required(assignment, constraints) else None
        var = remaining[0]
        for value in sorted(catalog[var], key=lambda p: p["price"]):
            trial = dict(assignment)
            trial[var] = value
            # prune early using only HARD constraints (soft constraints like budget
            # can only be fully evaluated once the whole bundle is assigned)
            if check_required(trial, hard_constraints):
                result = backtrack(trial, remaining[1:])
                if result is not None:
                    return result
        return None

    result = backtrack({}, order)
    if result is not None:
        return {"assignment": result, "feasible": True}

    return None


def solve_with_relaxation(catalog, preferences) -> Dict[str, Any]:
    """
    Try to solve with all soft constraints active. If infeasible, progressively
    relax the lowest-priority soft constraints (highest 'priority' number = relaxed first)
    until a solution is found or only hard constraints remain.
    """
    constraints = build_constraints(preferences)
    hard = [c for c in constraints if c.kind == "hard"]
    soft = sorted([c for c in constraints if c.kind == "soft"], key=lambda c: -c.priority)

    active_soft = list(soft)
    relaxed_log = []
    while True:
        trial_constraints = hard + active_soft
        result = backtracking_solve(catalog, trial_constraints)
        if result is not None:
            result["relaxed_constraints"] = relaxed_log
            return result
        if not active_soft:
            return {"assignment": None, "feasible": False, "relaxed_constraints": relaxed_log,
                     "reason": "No assignment satisfies even the hard constraints "
                               "(compatibility/stock/deadline) with this catalog."}
        dropped = active_soft.pop(0)  # lowest priority is relaxed first
        relaxed_log.append({"name": dropped.name, "description": dropped.description})


# ---------------------------------------------------------------------------
# Informed / uninformed search over the same state space (for comparison)
# ---------------------------------------------------------------------------

@dataclass(order=True)
class _Node:
    priority: float
    counter: int
    assignment: Dict[str, Any] = field(compare=False)
    cost: float = field(compare=False, default=0.0)


def _cheapest_remaining_cost(catalog, assigned_categories, order):
    total = 0.0
    for cat in order:
        if cat not in assigned_categories:
            total += min(p["price"] for p in catalog[cat])
    return total


def informed_search(catalog: Dict[str, List[dict]], constraints: List[Constraint],
                     strategy: str = "a_star", order: List[str] = None) -> Dict[str, Any]:
    """
    strategy in {"ucs", "greedy", "a_star"}.
    State = partial assignment. Goal = complete assignment satisfying hard constraints
    (soft constraints are used to prefer better solutions among goals via cost).
    Returns dict with assignment, cost, and number of nodes expanded (for comparison).
    """
    order = [c for c in (order or CATEGORY_ORDER) if c in catalog]
    hard = [c for c in constraints if c.kind == "hard"]

    counter = itertools.count()
    start = _Node(priority=0, counter=next(counter), assignment={}, cost=0.0)
    frontier = [start]
    expanded = 0
    best_goal = None

    while frontier:
        node = heapq.heappop(frontier)
        expanded += 1
        assignment = node.assignment
        assigned = list(assignment.keys())

        if len(assigned) == len(order):
            ok, _ = check_all(assignment, hard)
            if ok:
                if best_goal is None or node.cost < best_goal.cost:
                    best_goal = node
                    if strategy != "a_star":
                        break
                continue
            else:
                continue

        next_var = order[len(assigned)]
        for value in catalog[next_var]:
            trial = dict(assignment)
            trial[next_var] = value
            hard_ok, _ = check_all(trial, hard)
            if not hard_ok:
                continue
            g = node.cost + value["price"]
            if strategy == "ucs":
                priority = g
            elif strategy == "greedy":
                h = _cheapest_remaining_cost(catalog, trial.keys(), order)
                priority = h
            elif strategy == "a_star":
                h = _cheapest_remaining_cost(catalog, trial.keys(), order)
                priority = g + h
            else:
                raise ValueError(f"unknown strategy {strategy}")
            heapq.heappush(frontier, _Node(priority=priority, counter=next(counter),
                                            assignment=trial, cost=g))

    if best_goal is None:
        return {"assignment": None, "feasible": False, "expanded": expanded, "strategy": strategy}
    return {"assignment": best_goal.assignment, "cost": best_goal.cost,
            "feasible": True, "expanded": expanded, "strategy": strategy}


def compare_search_strategies(catalog, preferences) -> Dict[str, Any]:
    constraints = build_constraints(preferences)
    results = {}
    for strat in ("ucs", "greedy", "a_star"):
        results[strat] = informed_search(catalog, constraints, strategy=strat)
    return results
