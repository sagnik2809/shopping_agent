"""
Module 2: Planning

Models the shopping process as a sequential (STRIPS-style) planning problem.

Actions (name, preconditions on the world-state dict, effects on the world-state dict):
  SearchProducts        precond: none                          effect: catalog_loaded
  InspectSpecs           precond: catalog_loaded                effect: specs_known
  ValidateMemory(m)      precond: memory_flagged_uncertain(m)   effect: memory_validated(m)
  VerifyCompatibility    precond: specs_known                   effect: compatibility_verified
  AskClarification(slot) precond: slot_missing_or_conflicting   effect: slot_resolved
  CompareAlternatives    precond: compatibility_verified        effect: alternatives_compared
  ConstructRecommendation precond: alternatives_compared AND all flagged memories validated/resolved
                          effect: recommendation_built

The planner is a simple greedy forward planner: it only inserts information-gathering
actions (ValidateMemory / AskClarification) for memories/slots that Module 3's
uncertainty model actually flagged as needing verification, so it minimises unnecessary
questions while still guaranteeing that anything risky is checked before the final
recommendation action fires.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Set


@dataclass
class Action:
    name: str
    preconditions: Set[str]
    add_effects: Set[str]
    del_effects: Set[str] = field(default_factory=set)
    label: str = ""

    def applicable(self, state: Set[str]) -> bool:
        return self.preconditions.issubset(state)

    def apply(self, state: Set[str]) -> Set[str]:
        new_state = set(state)
        new_state -= self.del_effects
        new_state |= self.add_effects
        return new_state


def build_plan(memories_to_verify: List[str], slots_to_clarify: List[str]) -> List[Action]:
    """
    Constructs the fixed action library, parameterised by which memories/slots
    actually need attention (as decided upstream by the uncertainty module),
    then returns a valid, minimal-length plan via forward state-space search
    (here: a simple topological/greedy ordering, since the action library is small
    and mostly linear — this stands in for a general forward planner and is easy
    to swap for full STRIPS/GraphPlan later).
    """
    actions: List[Action] = []
    actions.append(Action("SearchProducts", set(), {"catalog_loaded"},
                           label="Search the catalog for candidate products"))
    actions.append(Action("InspectSpecs", {"catalog_loaded"}, {"specs_known"},
                           label="Inspect specifications of candidate products"))

    verify_flags = set()
    for m in memories_to_verify:
        flag = f"memory_validated:{m}"
        actions.append(Action(f"ValidateMemory:{m}", {"catalog_loaded"}, {flag},
                               label=f"Validate uncertain/suspicious memory '{m}' before use"))
        verify_flags.add(flag)

    clarify_flags = set()
    for s in slots_to_clarify:
        flag = f"slot_resolved:{s}"
        actions.append(Action(f"AskClarification:{s}", set(), {flag},
                               label=f"Ask the user to clarify/confirm preference '{s}'"))
        clarify_flags.add(flag)

    actions.append(Action("VerifyCompatibility", {"specs_known"}, {"compatibility_verified"},
                           label="Verify hard compatibility constraints (socket, RAM, PSU)"))
    actions.append(Action("CompareAlternatives", {"compatibility_verified"}, {"alternatives_compared"},
                           label="Compare compatible alternatives against constraints"))

    final_precond = {"alternatives_compared"} | verify_flags | clarify_flags
    actions.append(Action("ConstructRecommendation", final_precond, {"recommendation_built"},
                           label="Construct and explain the final recommendation"))

    # --- forward search for a valid ordering (goal = recommendation_built) ---
    goal = "recommendation_built"
    state: Set[str] = set()
    plan: List[Action] = []
    remaining = list(actions)
    guard = 0
    while goal not in state and guard < 100:
        guard += 1
        progressed = False
        for a in list(remaining):
            if a.applicable(state):
                state = a.apply(state)
                plan.append(a)
                remaining.remove(a)
                progressed = True
        if not progressed:
            break  # no applicable action left; plan may be incomplete (should not happen here)

    return plan


def explain_plan(plan: List[Action]) -> str:
    lines = []
    for i, a in enumerate(plan, 1):
        lines.append(f"{i}. {a.label or a.name}")
    return "\n".join(lines)
