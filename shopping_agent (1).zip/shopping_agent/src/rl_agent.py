"""
Module 4: Reinforcement Learning

Formulates "what should the agent do with a retrieved memory?" as an RL problem.

State space (discretised, one state per memory decision):
    (confidence_bucket, label, importance_bucket)
    confidence_bucket in {low, medium, high}   (thresholds 0.4, 0.7)
    label             in {RELIABLE, OUTDATED, CONFLICTING, UNCERTAIN_INFERRED, SUSPICIOUS}
    importance_bucket in {low, high}           (threshold 0.5)

Action space:
    USE            - trust the memory as-is
    VERIFY_USER    - ask the user to confirm/deny it
    SEARCH_EVIDENCE- cross-check it against other memories/recent behaviour (cheap, no user interruption)
    IGNORE         - temporarily discard it for this recommendation
    UPDATE         - overwrite with a corrected value (used after verification succeeds)
    REMOVE         - delete it from active memory permanently (used for confirmed-bad memories)

Reward function (per decision, used both to shape the rule-based baseline and to
train the tabular Q-learning agent in a simulated environment):
    + 2.0   if USE is chosen and the memory was actually correct
    - 5.0   if USE is chosen and the memory was actually corrupted/wrong (high-stakes penalty)
    - 0.5   cost of asking the user (VERIFY_USER) — annoyance penalty
    - 0.1   cost of SEARCH_EVIDENCE (cheap but not free)
    - 0.2   if IGNORE is chosen but the memory was actually correct (missed useful info)
    + 1.0   if IGNORE/REMOVE is chosen and the memory was actually corrupted
    + 0.5   bonus if VERIFY_USER or SEARCH_EVIDENCE correctly resolves a truly uncertain case

We train a small tabular Q-learning agent on a simulated MemoryEnv and compare its
learned policy against the deterministic rule-based policy derived from Module 3's
thresholds.
"""

from __future__ import annotations
import random
from collections import defaultdict
from typing import Dict, Optional, Tuple

ACTIONS = ["USE", "VERIFY_USER", "SEARCH_EVIDENCE", "IGNORE", "UPDATE", "REMOVE"]
LABELS = ["RELIABLE", "OUTDATED", "CONFLICTING", "UNCERTAIN_INFERRED", "SUSPICIOUS"]


def confidence_bucket(c: float) -> str:
    if c < 0.4:
        return "low"
    if c < 0.7:
        return "medium"
    return "high"


def importance_bucket(imp: float) -> str:
    return "high" if imp >= 0.5 else "low"


State = Tuple[str, str, str]


class MemoryEnv:
    """
    Simulated environment: each episode presents a random memory 'situation'
    (confidence, label, importance) along with a hidden ground-truth correctness
    flag that is statistically consistent with the label (e.g. SUSPICIOUS memories
    are almost always actually corrupted; RELIABLE ones are almost always correct).
    The agent picks one action and receives the reward defined above.
    """

    GROUND_TRUTH_CORRECT_PROB = {
        "RELIABLE": 0.95,
        "OUTDATED": 0.5,
        "CONFLICTING": 0.45,
        "UNCERTAIN_INFERRED": 0.55,
        "SUSPICIOUS": 0.03,
    }

    def __init__(self, seed: Optional[int] = None):
        self.rng = random.Random(seed)

    def sample_state(self) -> Tuple[State, bool]:
        label = self.rng.choice(LABELS)
        conf = {"RELIABLE": self.rng.uniform(0.7, 0.97),
                "OUTDATED": self.rng.uniform(0.3, 0.6),
                "CONFLICTING": self.rng.uniform(0.2, 0.55),
                "UNCERTAIN_INFERRED": self.rng.uniform(0.4, 0.7),
                "SUSPICIOUS": self.rng.uniform(0.0, 0.15)}[label]
        importance = self.rng.choice([0.3, 0.9])
        state = (confidence_bucket(conf), label, importance_bucket(importance))
        is_correct = self.rng.random() < self.GROUND_TRUTH_CORRECT_PROB[label]
        return state, is_correct

    def step(self, action: str, is_correct: bool) -> float:
        if action == "USE":
            return 2.0 if is_correct else -5.0
        if action == "VERIFY_USER":
            resolved_bonus = 0.5
            return -0.5 + resolved_bonus
        if action == "SEARCH_EVIDENCE":
            return -0.1 + 0.3
        if action == "IGNORE":
            return -0.2 if is_correct else 1.0
        if action == "REMOVE":
            return -1.0 if is_correct else 1.5  # removing a correct memory is costly
        if action == "UPDATE":
            return 0.5 if not is_correct else -0.3
        return 0.0


class QLearningAgent:
    def __init__(self, alpha=0.15, gamma=0.9, epsilon=0.2, seed: Optional[int] = None):
        self.q: Dict[Tuple[State, str], float] = defaultdict(float)
        self.alpha, self.gamma, self.epsilon = alpha, gamma, epsilon
        self.rng = random.Random(seed)

    def choose_action(self, state: State, greedy: bool = False) -> str:
        if not greedy and self.rng.random() < self.epsilon:
            return self.rng.choice(ACTIONS)
        qs = {a: self.q[(state, a)] for a in ACTIONS}
        max_q = max(qs.values())
        best = [a for a, v in qs.items() if v == max_q]
        return self.rng.choice(best)

    def update(self, state: State, action: str, reward: float, next_state: Optional[State]):
        max_next = max((self.q[(next_state, a)] for a in ACTIONS), default=0.0) if next_state else 0.0
        td_target = reward + self.gamma * max_next
        self.q[(state, action)] += self.alpha * (td_target - self.q[(state, action)])


def train(episodes: int = 20000, seed: int = 42) -> QLearningAgent:
    env = MemoryEnv(seed=seed)
    agent = QLearningAgent(seed=seed)
    for _ in range(episodes):
        state, is_correct = env.sample_state()
        action = agent.choose_action(state)
        reward = env.step(action, is_correct)
        agent.update(state, action, reward, next_state=None)  # single-step episodic task
    return agent


def rule_based_policy(state: State) -> str:
    """Deterministic baseline derived directly from Module 3's thresholds/labels."""
    conf_bucket, label, imp_bucket = state
    if label == "SUSPICIOUS":
        return "REMOVE"
    if label == "CONFLICTING":
        return "VERIFY_USER"
    if label == "OUTDATED":
        return "VERIFY_USER" if imp_bucket == "high" else "SEARCH_EVIDENCE"
    if label == "UNCERTAIN_INFERRED":
        return "SEARCH_EVIDENCE" if conf_bucket != "low" else "VERIFY_USER"
    # RELIABLE
    return "USE"


def evaluate_policy(policy_fn, episodes: int = 5000, seed: int = 123) -> float:
    env = MemoryEnv(seed=seed)
    total = 0.0
    for _ in range(episodes):
        state, is_correct = env.sample_state()
        action = policy_fn(state)
        total += env.step(action, is_correct)
    return total / episodes


def compare_policies(episodes: int = 5000) -> Dict[str, float]:
    trained_agent = train()
    q_policy = lambda s: trained_agent.choose_action(s, greedy=True)
    return {
        "q_learning_avg_reward": evaluate_policy(q_policy, episodes),
        "rule_based_avg_reward": evaluate_policy(rule_based_policy, episodes),
    }

