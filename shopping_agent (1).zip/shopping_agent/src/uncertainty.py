"""
Module 3: Reasoning under Uncertainty

Each stored memory is scored for reliability using a simple Bayesian-flavoured
combination of evidence:

  P(reliable | evidence) is approximated with a weighted log-odds update over
  independent "soft evidence" factors:
    - source prior:            user_stated > agent_inferred > third_party_injected
    - recency:                 exponential decay with memory age
    - usage frequency:         memories used often and successfully gain confidence
    - agreement with recent interactions
    - consistency with other stored memories (conflict detection)

The result is a posterior confidence in [0, 1] plus a categorical label:
  RELIABLE | OUTDATED | CONFLICTING | UNCERTAIN_INFERRED | SUSPICIOUS

A memory is flagged for verification (Module 2 inserts a ValidateMemory/AskClarification
action) whenever:
    expected_cost_of_error = (1 - confidence) * importance(slot)
  exceeds a verification-cost threshold, i.e. the risk of silently using bad
  information outweighs the cost of asking.
"""

from __future__ import annotations
import math
from dataclasses import dataclass
from typing import Dict, List, Optional


SOURCE_PRIOR = {
    "user_stated": 0.85,
    "agent_inferred": 0.55,
    "third_party_injected": 0.05,   # content pulled from product pages/reviews/ads is untrusted by default
}

# how costly a wrong value for this slot would be to the final recommendation
SLOT_IMPORTANCE = {
    "budget": 0.9,
    "brand_preference_cpu": 0.4,
    "brand_preference_gpu": 0.4,
    "delivery_deadline_days": 0.8,
    "min_ram_gb": 0.5,
    "priority_component": 0.3,
}

VERIFY_THRESHOLD = 0.25  # expected-cost-of-error above this triggers verification


def _logit(p: float) -> float:
    p = min(max(p, 1e-4), 1 - 1e-4)
    return math.log(p / (1 - p))


def _sigmoid(x: float) -> float:
    return 1 / (1 + math.exp(-x))


def _recency_factor(age_days: float) -> float:
    """Decays toward 0.5 (uninformative) as memories get old; half-life ~90 days."""
    half_life = 90.0
    decay = 0.5 ** (age_days / half_life)
    return 0.5 + 0.45 * decay  # bounded in (0.5, 0.95]


def _usage_factor(times_used: int) -> float:
    return 0.5 + 0.4 * (1 - math.exp(-times_used / 3.0))


@dataclass
class MemoryAssessment:
    memory_id: str
    slot: str
    confidence: float
    label: str
    needs_verification: bool
    rationale: str


def detect_conflicts(memories: List[dict]) -> Dict[str, List[dict]]:
    """
    Groups memories by slot to find genuine disagreements (e.g. two different
    user-stated budgets). Untrusted third-party-injected memories are excluded
    from this comparison: they are handled purely as SUSPICIOUS/malicious and
    must not be able to manufacture an apparent 'conflict' that drags a
    legitimate, independently reliable memory's label down.
    """
    trustworthy = [m for m in memories if m.get("source") != "third_party_injected"]
    by_slot: Dict[str, List[dict]] = {}
    for m in trustworthy:
        by_slot.setdefault(m["slot"], []).append(m)
    conflicts = {slot: ms for slot, ms in by_slot.items()
                 if len({m["value"] for m in ms}) > 1}
    return conflicts


def assess_memory(memory: dict, conflicts: Dict[str, List[dict]]) -> MemoryAssessment:
    source = memory.get("source", "agent_inferred")
    prior = SOURCE_PRIOR.get(source, 0.5)

    evidence_logit = _logit(prior)
    evidence_logit += _logit(_recency_factor(memory.get("age_days", 0)))
    evidence_logit += _logit(_usage_factor(memory.get("times_used", 0)))
    evidence_logit += _logit(min(max(memory.get("agreement_with_recent", 0.5), 0.01), 0.99))

    confidence = _sigmoid(evidence_logit / 4.0)  # average the log-odds contributions

    is_conflicting = memory["slot"] in conflicts
    reasons = [f"source={source} (prior={prior:.2f})",
               f"age={memory.get('age_days')}d",
               f"used={memory.get('times_used')}x",
               f"agreement={memory.get('agreement_with_recent')}"]

    if source == "third_party_injected":
        label = "SUSPICIOUS"
        confidence = min(confidence, 0.1)
        reasons.append("originates from untrusted third-party content (product page/review) — "
                        "cannot be used to alter trusted preference memory")
    elif is_conflicting:
        label = "CONFLICTING"
        reasons.append(f"conflicts with {len(conflicts[memory['slot']]) - 1} other memor(y/ies) for slot '{memory['slot']}'")
    elif memory.get("age_days", 0) > 150:
        label = "OUTDATED"
    elif source == "agent_inferred":
        label = "UNCERTAIN_INFERRED"
    else:
        label = "RELIABLE"

    importance = SLOT_IMPORTANCE.get(memory["slot"], 0.4)
    expected_cost_of_error = (1 - confidence) * importance
    needs_verification = expected_cost_of_error > VERIFY_THRESHOLD or label in (
        "SUSPICIOUS", "CONFLICTING", "OUTDATED")

    rationale = f"{label}: " + "; ".join(reasons) + \
                f" -> confidence={confidence:.2f}, expected_cost_of_error={expected_cost_of_error:.2f}"

    return MemoryAssessment(memory_id=memory["id"], slot=memory["slot"], confidence=confidence,
                             label=label, needs_verification=needs_verification, rationale=rationale)


def assess_all(memories: List[dict]) -> List[MemoryAssessment]:
    conflicts = detect_conflicts(memories)
    return [assess_memory(m, conflicts) for m in memories]


def usable_preferences(memories: List[dict], assessments: List[MemoryAssessment],
                        min_confidence: float = 0.5) -> Dict[str, dict]:
    """
    Collapses memories into a single trusted preference dict, picking the
    highest-confidence non-suspicious memory per slot, and skipping slots
    where nothing meets min_confidence (those get flagged for clarification instead).
    """
    by_id = {a.memory_id: a for a in assessments}
    best_per_slot: Dict[str, dict] = {}
    for m in memories:
        a = by_id[m["id"]]
        if a.label == "SUSPICIOUS":
            continue
        if a.confidence < min_confidence:
            continue
        current = best_per_slot.get(m["slot"])
        if current is None or a.confidence > by_id[current["id"]].confidence:
            best_per_slot[m["slot"]] = m
    return best_per_slot
